import { S as StorageKit, T as computed, a9 as sendMessageToExtension, d as defineComponent, R as useApp, N as ref, aa as watchEffect, o as openBlock, c as createElementBlock, a as createBaseVNode, a3 as toDisplayString, u as unref, F as Fragment, ab as renderList, ac as normalizeStyle, n as normalizeClass, ad as pushScopeId, ae as popScopeId, a2 as createCommentVNode, O as watch, W as useAuth, a1 as createBlock, af as resolveDynamicComponent, ag as isRef, ah as toRefs$1, ai as customRef, U as onMounted, aj as nextTick, ak as getCurrentScope, y as getCurrentInstance, al as onScopeDispose, am as provide, H as createVNode, an as injectCustomScript } from "./useAuth-f1cb8d10.js";
import { d as dispatchEventHandler, g as getElementByXpath, u as useDevAccountStore, t as transformUrl, a as useLinkGoStore, b as getAllStorage, c as useStoragePortalStore, e as useClickCountStore, _ as _export_sfc, f as createApp, s as setStyle, h as getStyle, i as useUrlBlockStore, w as webNotice, E as Empty, j as contentInstall, k as getFaviconUrl } from "./install-610148a8.js";
import { M as Message } from "./message-d1775bf2.js";
import { w as withModifiers, c as createApp$1, u as useTheme } from "./useTheme-65349a24.js";
import { _ as _sfc_main$5 } from "./Cover.vue_vue_type_script_setup_true_lang-81c14e90.js";
import { _ as _sfc_main$6 } from "./ToolItem.vue_vue_type_script_setup_true_lang-2917be7e.js";
import { i as injectPostMessage } from "./util-9e04540b.js";
import "./logo-219d4073.js";
const defaultStore = () => {
  return {
    actions: []
  };
};
const STORE_KEY = "AppContentAction";
const useContentAction = () => {
  const storageKit = StorageKit.getInstance(
    STORE_KEY,
    defaultStore()
  );
  const get = async (url) => {
    var _a, _b;
    while (!storageKit.inited) {
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    return ((_b = (_a = storageKit.store.actions) == null ? void 0 : _a.find((n) => n.url === url)) == null ? void 0 : _b.plugins) || [];
  };
  const add = async (url, action) => {
    var _a, _b;
    const isExist = (_a = storageKit.store.actions) == null ? void 0 : _a.find(
      (n) => n.url === url && n.plugins.find((x) => x.key === action.key)
    );
    const plugins = (_b = storageKit.store.actions) == null ? void 0 : _b.find((n) => n.url === url);
    if (!isExist) {
      storageKit.storeRaw.value.actions.push({
        url,
        plugins: [...(plugins == null ? void 0 : plugins.plugins) || [], action]
      });
    }
    storageKit.save();
  };
  const clear = (url) => {
    var _a;
    storageKit.storeRaw.value.actions = (_a = storageKit.store.actions) == null ? void 0 : _a.filter(
      (n) => n.url !== url
    );
    storageKit.save();
  };
  const remove = (url, key) => {
    var _a;
    storageKit.storeRaw.value.actions.map((n) => {
      if (n.url === url) {
        n.plugins = n.plugins.filter((x) => x.key !== key);
      }
      return n;
    });
    storageKit.storeRaw.value.actions = (_a = storageKit.store.actions) == null ? void 0 : _a.filter(
      (n) => n.plugins.length > 0
    );
    storageKit.save();
  };
  const isUpdate = computed(() => {
    return storageKit.update_key.value;
  });
  return {
    remove,
    clear,
    add,
    get,
    isUpdate
  };
};
const elementCssSelector = (css) => {
  let el = null;
  for (let i = 0; i < css.length; i++) {
    try {
      el = document.body.querySelector(css[i]);
    } catch (error) {
    }
    if (el)
      break;
  }
  return el;
};
const elementXPath = (xpath) => {
  let el = null;
  for (let i = 0; i < xpath.length; i++) {
    try {
      el = getElementByXpath(xpath[i]);
    } catch (error) {
    }
    if (el)
      break;
  }
  return el;
};
const elementPlaceholder = (placeholder) => {
  let el = null;
  for (let i = 0; i < placeholder.length; i++) {
    try {
      el = document.querySelector(
        `input[placeholder*="${placeholder[i]}"]`
      );
    } catch (error) {
    }
    if (el)
      break;
  }
  return el;
};
const getElement = (config) => {
  let el = null;
  if (config.cssSeletor) {
    el = elementCssSelector(config.cssSeletor);
  }
  if (!el && config.placeholder) {
    el = elementPlaceholder(config.placeholder);
  }
  if (!el && config.xpath) {
    el = elementXPath(config.xpath);
  }
  return el;
};
const autoInput = (userInfo) => {
  const { account, password, validate, loginBtn } = userInfo.rules;
  const { autoLogin, code } = userInfo.options;
  const userEl = getElement(account);
  const passWordEl = getElement(password);
  const validateEl = getElement(validate);
  const loginEle = getElement(loginBtn);
  if (userEl && passWordEl) {
    dispatchEventHandler("focus", userEl);
    userEl.value = userInfo.user.name;
    dispatchEventHandler("input", userEl, {
      data: userInfo.user.name
    });
    dispatchEventHandler("change", userEl, {
      data: userInfo.user.name
    });
    dispatchEventHandler("blur", userEl);
    dispatchEventHandler("focus", passWordEl);
    passWordEl.value = userInfo.user.password;
    dispatchEventHandler("input", passWordEl, {
      data: userInfo.user.password
    });
    dispatchEventHandler("change", passWordEl, {
      data: userInfo.user.password
    });
    dispatchEventHandler("blur", passWordEl);
    if (validateEl) {
      validateEl.value = code || "";
      dispatchEventHandler("input", validateEl);
    }
    setTimeout(() => {
      if (autoLogin && loginEle) {
        dispatchEventHandler("mousedown", loginEle);
        dispatchEventHandler("mouseup", loginEle);
        dispatchEventHandler("click", loginEle);
        if ((loginEle == null ? void 0 : loginEle.type) === "submit") {
          const formEl = loginEle.closest("form");
          if (formEl) {
            dispatchEventHandler("submit", formEl);
          }
        }
      }
    }, 0);
  }
};
const userLogin = (user, web) => {
  autoInput({
    user,
    rules: web.match,
    options: {
      code: web.code,
      autoLogin: web.autoLogin
    }
  });
};
const shortcutAutoLogin = async () => {
  const { getMatch } = useDevAccountStore();
  const match = await getMatch(window.location.href);
  if (!match)
    return;
  const loginBtn = getElement(match.match.loginBtn);
  const { add, remove } = useContentAction();
  if (!loginBtn) {
    remove(transformUrl(window.location.href), "auto-login");
    return;
  }
  add(transformUrl(window.location.href), {
    title: "自动登录",
    code: "DevAccount",
    key: "auto-login"
  });
};
const shortcutTryResgister = () => {
};
const registerShortcut = async () => {
  await shortcutAutoLogin();
  await shortcutTryResgister();
};
const devAccount = async (option) => {
  const { key } = option;
  if (key === "user-login") {
    const { web, user } = option.data;
    if (!user)
      return;
    userLogin(user, web);
  }
  if (key === "register-shortcut") {
    registerShortcut();
  }
  if (key === "auto-login") {
    const { getMatch } = useDevAccountStore();
    const match = await getMatch(window.location.href);
    if (!match)
      return;
    const defaultUser = match.users.find((u) => u.isDefault);
    if (!defaultUser)
      return;
    autoInput({
      user: defaultUser,
      rules: match.match,
      options: {
        code: match.code,
        autoLogin: true
      }
    });
  }
};
const { rules, parseUrl, inited } = useLinkGoStore();
const linkGo = async () => {
  while (!inited.value) {
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  const url = window.location.href;
  let href;
  for (let i = 0; i < rules.value.length; i++) {
    href = parseUrl(url, rules.value[i]);
    if (href)
      break;
  }
  if (href)
    window.location.href = new URL(href).href;
};
const storagePortal = (opt) => {
  if (opt.key === "send-storage") {
    const _localStorage = getAllStorage(localStorage);
    const _sessionStorage = getAllStorage(sessionStorage);
    sendMessageToExtension({
      from: Message.Form.CONTENT_MESSAGE,
      to: Message.Target.SERVERWORKER,
      code: "onSendData",
      data: {
        key: "send-storage",
        opt: {
          targetUrl: opt.from,
          soureurl: new URL(window.location.href).host,
          localStorage: _localStorage,
          sessionStorage: _sessionStorage
        }
      }
    });
  }
  if (opt.key === "get-storage") {
    const { setStore } = useStoragePortalStore();
    setStore(
      {
        sessionStorage: opt.data.opt.sessionStorage,
        localStorage: opt.data.opt.localStorage
      },
      true
    );
  }
  if (opt.key === "get-cookies") {
    const { setStore } = useStoragePortalStore();
    const cookies = /* @__PURE__ */ new Map();
    opt.data.cookies.forEach((c) => {
      cookies.set(c.name, {
        key: c.name,
        val: c.value
      });
    });
    const rst = [];
    cookies.forEach((c) => {
      if (c.key)
        rst.push(c);
    });
    setStore({ cookie: rst }, true);
  }
  if (opt.key === "get-tabs") {
    const options = [];
    opt.data.openWebSites.forEach((o) => {
      const isExclude = options.some((item) => item.url === new URL(o.url).host) || new URL(o.url).host === new URL(window.location.href).host || o.url.startsWith("chrome://");
      if (!isExclude) {
        options.push({
          url: new URL(o.url).host,
          title: o.title
        });
      }
    });
    const { setTabs } = useStoragePortalStore();
    setTabs(options);
  }
};
const _withScopeId = (n) => (pushScopeId("data-v-a4ee78a6"), n = n(), popScopeId(), n);
const _hoisted_1$4 = { class: "click-header" };
const _hoisted_2$3 = { class: "count-value" };
const _hoisted_3$3 = { style: { "font-size": "24px" } };
const _hoisted_4$3 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("span", null, "次", -1));
const _hoisted_5$3 = { class: "btn-group" };
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "click-count",
  setup(__props) {
    const { count, add, status, set } = useClickCountStore();
    const { setPopupActive } = useApp();
    const data = ref([]);
    watchEffect(() => {
      if (count.value === 0) {
        data.value = [];
      }
    });
    const handleClick = async (e) => {
      const parent = document.getElementById("click-count");
      if (parent == null ? void 0 : parent.contains(e.target))
        return;
      if (status.value !== 1)
        return;
      await add(1);
      const x = e.clientX;
      const y = e.clientY;
      const id = Date.now();
      const time = Date.now();
      const color = `hsl(${Math.random() * 360}, 100%, 50%)`;
      const val = count.value;
      data.value.push({ x, y, id, time, color, val });
    };
    const handleStop = () => {
      removeView();
      setPopupActive();
      set(0);
    };
    const canClick = computed(() => status.value === 1);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["click-count", { "event-effect": canClick.value }]),
        onClick: handleClick
      }, [
        createBaseVNode("div", _hoisted_1$4, [
          createBaseVNode("div", _hoisted_2$3, [
            createBaseVNode("span", _hoisted_3$3, toDisplayString(unref(count)), 1),
            _hoisted_4$3
          ]),
          createBaseVNode("div", _hoisted_5$3, [
            createBaseVNode("div", {
              class: "btn",
              onClick: _cache[0] || (_cache[0] = withModifiers(() => handleStop(), ["stop"]))
            }, "结束")
          ])
        ]),
        (openBlock(true), createElementBlock(Fragment, null, renderList(data.value, (item) => {
          return openBlock(), createElementBlock("div", {
            key: item.id,
            class: "click-item",
            style: normalizeStyle({
              left: `${item.x}px`,
              top: `${item.y}px`,
              background: item.color
            })
          }, toDisplayString(item.val), 5);
        }), 128))
      ], 2);
    };
  }
});
const clickCount_vue_vue_type_style_index_0_scoped_a4ee78a6_shadow_clickCount_lang = "";
const Count = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-a4ee78a6"]]);
const APP_SELCTOR$1 = "click-count";
let app;
const injectView = () => {
  const isExist = document.querySelector(`#${APP_SELCTOR$1}`);
  if (isExist)
    return true;
  app = createApp({
    app: { component: Count },
    config: { appSelector: "click-count", predStyle: "assets/click-count.css" }
  });
};
const removeView = () => {
  var _a, _b;
  if (app)
    app.unmount();
  const el = (_a = document.body) == null ? void 0 : _a.querySelector(`#${APP_SELCTOR$1}`);
  el && ((_b = el.parentNode) == null ? void 0 : _b.removeChild(el));
};
const initClickCount = async () => {
  const { status } = useClickCountStore();
  if ([1, 2, 3].includes(status.value)) {
    const timer = setTimeout(() => {
      const isExist = injectView();
      if (isExist)
        clearTimeout(timer);
    }, 100);
  } else {
    removeView();
  }
};
const clickCount = ({ key }) => {
  if (key === "init-click")
    initClickCount();
  if (key === "stop-click")
    removeView();
};
const _hoisted_1$3 = {
  key: 0,
  style: { "width": "100%", "height": "100%", "display": "flex", "align-items": "center", "justify-content": "center", "background-color": "#f4f4f4", "border-radius": "4px", "opacity": "0.9", "color": "#999", "font-weight": "700" }
};
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "block-content",
  props: {
    targetElement: {
      type: Object,
      required: true
    },
    engine: {
      type: String,
      required: true
    },
    onRemove: {
      type: Function
    }
  },
  setup(__props) {
    const props = __props;
    const isBlock = ref(false);
    const originPosition = ref({});
    const remove = () => {
      setStyle(props.targetElement, {
        ...originPosition.value
      });
      props.targetElement.removeAttribute("data-blocked");
      isBlock.value = false;
      if (props.onRemove)
        props.onRemove();
    };
    const init = () => {
      if (props.targetElement.getAttribute("data-blocked"))
        return;
      originPosition.value = {
        position: getStyle(props.targetElement, "position"),
        height: getStyle(props.targetElement, "height"),
        overflow: getStyle(props.targetElement, "overflow")
      };
      setStyle(props.targetElement, {
        position: "relative",
        height: "40px",
        overflow: "hidden"
      });
      props.targetElement.setAttribute("data-blocked", "true");
      isBlock.value = true;
    };
    init();
    return (_ctx, _cache) => {
      return isBlock.value ? (openBlock(), createElementBlock("div", _hoisted_1$3, [
        createBaseVNode("div", {
          style: { "color": "#999", "cursor": "pointer" },
          onClick: remove
        }, "查看")
      ])) : createCommentVNode("", true);
    };
  }
});
const getPropByPath = (obj, path) => {
  let tempObj = obj;
  path = path.replace(/\[(\w+)\]/g, ".$1");
  path = path.replace(/^\./, "");
  const keyArr = path.split(".");
  let i = 0;
  for (let len = keyArr.length; i < len - 1; ++i) {
    const key = keyArr[i];
    if (key in tempObj) {
      tempObj = tempObj[key];
    } else {
      throw new Error(
        "[iView warn]: please transfer a valid prop path to form item!"
      );
    }
  }
  return tempObj[keyArr[i]];
};
const injectBlockView = (target, engine) => {
  const blockElement = document.createElement("div");
  blockElement.setAttribute("style", "position: absolute; inset: 0;");
  const removeBlockElement = () => {
    target.removeChild(blockElement);
  };
  const app2 = createApp$1(_sfc_main$3, {
    targetElement: target,
    engine,
    onRemove: removeBlockElement
  });
  app2.mount(blockElement);
  target.appendChild(blockElement);
};
const getUrlText = (item, target) => {
  if (target.attribute) {
    return item.getAttribute(target.attribute) || "";
  }
  if (target.path) {
    return getPropByPath(item, target.path);
  }
  return "";
};
const isBlockUrl = (url, blackList) => {
  let flag = false;
  blackList.forEach((b) => {
    if (b.type === "regex") {
      if (Array.isArray(b.value)) {
        b.value.forEach((v) => {
          if (url.match(v)) {
            flag = true;
          }
        });
      } else if (url.includes(b.value)) {
        flag = true;
      }
    }
    if (b.type === "string") {
      if (Array.isArray(b.value) && b.value.includes(url)) {
        flag = true;
      } else if (url.includes(b.value)) {
        flag = true;
      }
    }
  });
  return flag;
};
const extractHostFromUrl = (text) => {
  const regex = /(?:https?:\/\/)?([^:\/\s]+\.[^:\/\s]+)/;
  const match = text.match(regex);
  return match ? match[1] : text;
};
const urlBlock = async () => {
  const { enableBlackList, getEnfineConfig, inited: inited2 } = useUrlBlockStore();
  while (!inited2.value) {
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  const engineConfig = getEnfineConfig(document.location.host);
  if (engineConfig) {
    if (engineConfig.delay) {
      await new Promise((resolve) => setTimeout(resolve, engineConfig.delay));
    }
    const list = document.querySelectorAll(engineConfig.query.target.selector);
    Array.from(list).forEach((item) => {
      let urlText = getUrlText(item, engineConfig.query.target);
      urlText = extractHostFromUrl(urlText);
      if (urlText) {
        try {
          if (!urlText.startsWith("https://") && !urlText.startsWith("http://")) {
            urlText = `https://${urlText}`;
          }
          const url = new URL(urlText).host;
          if (url && isBlockUrl(url, enableBlackList.value)) {
            const container = item.closest(engineConfig.query.container);
            const isBlock = container == null ? void 0 : container.getAttribute("data-blocked");
            if (container && !isBlock) {
              injectBlockView(container, engineConfig.engine);
            }
          }
        } catch (error) {
        }
      }
    });
  }
};
const contentFunc = {
  WebNotice: webNotice,
  DevAccount: devAccount,
  LinkGo: linkGo,
  StoragePortal: storagePortal,
  ClickCount: clickCount,
  UrlBlock: urlBlock
};
const coreRelaod = (option) => {
  const { reload } = option;
  if (Array.isArray(reload)) {
    if (reload.some((url) => window.location.href.includes(url))) {
      window.location.reload();
    }
  } else if (typeof reload === "boolean" && reload) {
    window.location.reload();
  }
};
const contentCore = (options) => {
  if (!options)
    return;
  const { key, data } = options;
  if (key === "doc-reload")
    coreRelaod(data);
};
const injectScript = "/assets/index.ts-03498af6.js";
const _hoisted_1$2 = { class: "dev-tester-dialog-header" };
const _hoisted_2$2 = /* @__PURE__ */ createBaseVNode("span", null, null, -1);
const _hoisted_3$2 = {
  key: 0,
  class: "dev-tester-dialog-title"
};
const _hoisted_4$2 = ["src"];
const _hoisted_5$2 = /* @__PURE__ */ createBaseVNode("path", {
  fill: "currentColor",
  d: "M764.288 214.592 512 466.88 259.712 214.592a31.936 31.936 0 0 0-45.12 45.12L466.752 512 214.528 764.224a31.936 31.936 0 1 0 45.12 45.184L512 557.184l252.288 252.288a31.936 31.936 0 0 0 45.12-45.12L557.12 512.064l252.288-252.352a31.936 31.936 0 1 0-45.12-45.184z"
}, null, -1);
const _hoisted_6$1 = [
  _hoisted_5$2
];
const _hoisted_7 = { class: "dev-tester-dialog-body" };
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "Dialog",
  props: {
    modelValue: {
      type: Boolean,
      default: false
    },
    direction: {
      type: String,
      default: "left"
    },
    tool: {
      type: Object,
      default: () => ({})
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { expose: __expose, emit }) {
    const props = __props;
    const stateVisable = ref(false);
    watch(
      () => props.modelValue,
      (val) => {
        stateVisable.value = val;
      }
    );
    const show = () => {
      stateVisable.value = true;
    };
    const close = () => {
      stateVisable.value = false;
      emit("update:modelValue", false);
    };
    const { isLogin } = useAuth();
    __expose({
      show
    });
    return (_ctx, _cache) => {
      return stateVisable.value ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: normalizeClass(`dev-tester-dialog dev-tester-${__props.direction}`),
        style: normalizeStyle({ width: __props.tool.width || "400px" })
      }, [
        createBaseVNode("div", _hoisted_1$2, [
          _hoisted_2$2,
          unref(isLogin) || !__props.tool.isLogin ? (openBlock(), createElementBlock("span", _hoisted_3$2, [
            createBaseVNode("img", {
              class: "tool-logo",
              src: __props.tool.logo
            }, null, 8, _hoisted_4$2),
            createBaseVNode("span", null, toDisplayString(__props.tool.title), 1)
          ])) : createCommentVNode("", true),
          (openBlock(), createElementBlock("svg", {
            class: "dev-tester-dialog-close",
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 1024 1024",
            onClick: close
          }, _hoisted_6$1))
        ]),
        createBaseVNode("div", _hoisted_7, [
          !unref(isLogin) && __props.tool.isLogin ? (openBlock(), createBlock(_sfc_main$5, {
            key: 0,
            "is-inject": true
          })) : !__props.tool.name ? (openBlock(), createBlock(unref(Empty), { key: 1 })) : (openBlock(), createBlock(resolveDynamicComponent(`Inject${__props.tool.name}`), { key: 2 }))
        ])
      ], 6)) : createCommentVNode("", true);
    };
  }
});
function tryOnScopeDispose(fn) {
  if (getCurrentScope()) {
    onScopeDispose(fn);
    return true;
  }
  return false;
}
function toValue(r) {
  return typeof r === "function" ? r() : unref(r);
}
const isClient = typeof window !== "undefined" && typeof document !== "undefined";
typeof WorkerGlobalScope !== "undefined" && globalThis instanceof WorkerGlobalScope;
const toString = Object.prototype.toString;
const isObject = (val) => toString.call(val) === "[object Object]";
const noop = () => {
};
function getLifeCycleTarget(target) {
  return target || getCurrentInstance();
}
function toRefs(objectRef, options = {}) {
  if (!isRef(objectRef))
    return toRefs$1(objectRef);
  const result = Array.isArray(objectRef.value) ? Array.from({ length: objectRef.value.length }) : {};
  for (const key in objectRef.value) {
    result[key] = customRef(() => ({
      get() {
        return objectRef.value[key];
      },
      set(v) {
        var _a;
        const replaceRef = (_a = toValue(options.replaceRef)) != null ? _a : true;
        if (replaceRef) {
          if (Array.isArray(objectRef.value)) {
            const copy = [...objectRef.value];
            copy[key] = v;
            objectRef.value = copy;
          } else {
            const newObject = { ...objectRef.value, [key]: v };
            Object.setPrototypeOf(newObject, Object.getPrototypeOf(objectRef.value));
            objectRef.value = newObject;
          }
        } else {
          objectRef.value[key] = v;
        }
      }
    }));
  }
  return result;
}
function tryOnMounted(fn, sync = true, target) {
  const instance = getLifeCycleTarget();
  if (instance)
    onMounted(fn, target);
  else if (sync)
    fn();
  else
    nextTick(fn);
}
function unrefElement(elRef) {
  var _a;
  const plain = toValue(elRef);
  return (_a = plain == null ? void 0 : plain.$el) != null ? _a : plain;
}
const defaultWindow = isClient ? window : void 0;
function useEventListener(...args) {
  let target;
  let events;
  let listeners;
  let options;
  if (typeof args[0] === "string" || Array.isArray(args[0])) {
    [events, listeners, options] = args;
    target = defaultWindow;
  } else {
    [target, events, listeners, options] = args;
  }
  if (!target)
    return noop;
  if (!Array.isArray(events))
    events = [events];
  if (!Array.isArray(listeners))
    listeners = [listeners];
  const cleanups = [];
  const cleanup = () => {
    cleanups.forEach((fn) => fn());
    cleanups.length = 0;
  };
  const register = (el, event, listener, options2) => {
    el.addEventListener(event, listener, options2);
    return () => el.removeEventListener(event, listener, options2);
  };
  const stopWatch = watch(
    () => [unrefElement(target), toValue(options)],
    ([el, options2]) => {
      cleanup();
      if (!el)
        return;
      const optionsClone = isObject(options2) ? { ...options2 } : options2;
      cleanups.push(
        ...events.flatMap((event) => {
          return listeners.map((listener) => register(el, event, listener, optionsClone));
        })
      );
    },
    { immediate: true, flush: "post" }
  );
  const stop = () => {
    stopWatch();
    cleanup();
  };
  tryOnScopeDispose(stop);
  return stop;
}
function useMounted() {
  const isMounted = ref(false);
  const instance = getCurrentInstance();
  if (instance) {
    onMounted(() => {
      isMounted.value = true;
    }, instance);
  }
  return isMounted;
}
function useSupported(callback) {
  const isMounted = useMounted();
  return computed(() => {
    isMounted.value;
    return Boolean(callback());
  });
}
function useMediaQuery(query, options = {}) {
  const { window: window2 = defaultWindow } = options;
  const isSupported = useSupported(() => window2 && "matchMedia" in window2 && typeof window2.matchMedia === "function");
  let mediaQuery;
  const matches = ref(false);
  const handler = (event) => {
    matches.value = event.matches;
  };
  const cleanup = () => {
    if (!mediaQuery)
      return;
    if ("removeEventListener" in mediaQuery)
      mediaQuery.removeEventListener("change", handler);
    else
      mediaQuery.removeListener(handler);
  };
  const stopWatch = watchEffect(() => {
    if (!isSupported.value)
      return;
    cleanup();
    mediaQuery = window2.matchMedia(toValue(query));
    if ("addEventListener" in mediaQuery)
      mediaQuery.addEventListener("change", handler);
    else
      mediaQuery.addListener(handler);
    matches.value = mediaQuery.matches;
  });
  tryOnScopeDispose(() => {
    stopWatch();
    cleanup();
    mediaQuery = void 0;
  });
  return matches;
}
function useDraggable(target, options = {}) {
  var _a, _b;
  const {
    pointerTypes,
    preventDefault,
    stopPropagation,
    exact,
    onMove,
    onEnd,
    onStart,
    initialValue,
    axis = "both",
    draggingElement = defaultWindow,
    containerElement,
    handle: draggingHandle = target
  } = options;
  const position = ref(
    (_a = toValue(initialValue)) != null ? _a : { x: 0, y: 0 }
  );
  const pressedDelta = ref();
  const filterEvent = (e) => {
    if (pointerTypes)
      return pointerTypes.includes(e.pointerType);
    return true;
  };
  const handleEvent = (e) => {
    if (toValue(preventDefault))
      e.preventDefault();
    if (toValue(stopPropagation))
      e.stopPropagation();
  };
  const start = (e) => {
    var _a2;
    if (toValue(options.disabled) || !filterEvent(e))
      return;
    if (toValue(exact) && e.target !== toValue(target))
      return;
    const container = toValue(containerElement);
    const containerRect = (_a2 = container == null ? void 0 : container.getBoundingClientRect) == null ? void 0 : _a2.call(container);
    const targetRect = toValue(target).getBoundingClientRect();
    const pos = {
      x: e.clientX - (container ? targetRect.left - containerRect.left + container.scrollLeft : targetRect.left),
      y: e.clientY - (container ? targetRect.top - containerRect.top + container.scrollTop : targetRect.top)
    };
    if ((onStart == null ? void 0 : onStart(pos, e)) === false)
      return;
    pressedDelta.value = pos;
    handleEvent(e);
  };
  const move = (e) => {
    if (toValue(options.disabled) || !filterEvent(e))
      return;
    if (!pressedDelta.value)
      return;
    const container = toValue(containerElement);
    const targetRect = toValue(target).getBoundingClientRect();
    let { x, y } = position.value;
    if (axis === "x" || axis === "both") {
      x = e.clientX - pressedDelta.value.x;
      if (container)
        x = Math.min(Math.max(0, x), container.scrollWidth - targetRect.width);
    }
    if (axis === "y" || axis === "both") {
      y = e.clientY - pressedDelta.value.y;
      if (container)
        y = Math.min(Math.max(0, y), container.scrollHeight - targetRect.height);
    }
    position.value = {
      x,
      y
    };
    onMove == null ? void 0 : onMove(position.value, e);
    handleEvent(e);
  };
  const end = (e) => {
    if (toValue(options.disabled) || !filterEvent(e))
      return;
    if (!pressedDelta.value)
      return;
    pressedDelta.value = void 0;
    onEnd == null ? void 0 : onEnd(position.value, e);
    handleEvent(e);
  };
  if (isClient) {
    const config = { capture: (_b = options.capture) != null ? _b : true };
    useEventListener(draggingHandle, "pointerdown", start, config);
    useEventListener(draggingElement, "pointermove", move, config);
    useEventListener(draggingElement, "pointerup", end, config);
  }
  return {
    ...toRefs(position),
    position,
    isDragging: computed(() => !!pressedDelta.value),
    style: computed(
      () => `left:${position.value.x}px;top:${position.value.y}px;`
    )
  };
}
function useWindowSize(options = {}) {
  const {
    window: window2 = defaultWindow,
    initialWidth = Number.POSITIVE_INFINITY,
    initialHeight = Number.POSITIVE_INFINITY,
    listenOrientation = true,
    includeScrollbar = true
  } = options;
  const width = ref(initialWidth);
  const height = ref(initialHeight);
  const update = () => {
    if (window2) {
      if (includeScrollbar) {
        width.value = window2.innerWidth;
        height.value = window2.innerHeight;
      } else {
        width.value = window2.document.documentElement.clientWidth;
        height.value = window2.document.documentElement.clientHeight;
      }
    }
  };
  update();
  tryOnMounted(update);
  useEventListener("resize", update, { passive: true });
  if (listenOrientation) {
    const matches = useMediaQuery("(orientation: portrait)");
    watch(matches, () => update());
  }
  return { width, height };
}
const App = "";
const logo = "/assets/logo16.png";
const _hoisted_1$1 = {
  key: 0,
  class: "action-tips z-index"
};
const _hoisted_2$1 = ["onClick"];
const _hoisted_3$1 = { class: "action-tips-app" };
const _hoisted_4$1 = ["src"];
const _hoisted_5$1 = { class: "action-tips-title" };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "ActionTips",
  setup(__props) {
    const { get, isUpdate } = useContentAction();
    const { getAppInfo } = useApp();
    const actions = ref([]);
    const init = async () => {
      actions.value = [];
      const _actions = await get(transformUrl(window.location.href));
      if (_actions.length) {
        actions.value = _actions.map((action) => {
          const app2 = getAppInfo(action.code);
          return {
            appIcon: app2.logo,
            appName: app2.name,
            ...action
          };
        });
      }
    };
    watch(
      () => isUpdate.value,
      (val) => {
        init();
      }
    );
    init();
    const handleShotcut = (action) => {
      sendMessageToExtension({
        from: Message.Form.CONTENT_MESSAGE,
        to: Message.Target.SERVERWORKER,
        code: "onShortcut",
        data: {
          key: action.key,
          data: action.data || {}
        }
      });
    };
    return (_ctx, _cache) => {
      return actions.value.length ? (openBlock(), createElementBlock("div", _hoisted_1$1, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(actions.value, (action) => {
          return openBlock(), createElementBlock("div", {
            key: action.title,
            class: "action-tips-item",
            onClick: ($event) => handleShotcut(action)
          }, [
            createBaseVNode("div", _hoisted_3$1, [
              createBaseVNode("img", {
                class: "app-logo",
                src: action.appIcon
              }, null, 8, _hoisted_4$1)
            ]),
            createBaseVNode("div", _hoisted_5$1, toDisplayString(action.title), 1)
          ], 8, _hoisted_2$1);
        }), 128))
      ])) : createCommentVNode("", true);
    };
  }
});
const _hoisted_1 = ["src"];
const _hoisted_2 = { class: "dev-tester-content" };
const _hoisted_3 = { class: "dev-tester-footer" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("span", { class: "line" }, null, -1);
const _hoisted_5 = ["onClick"];
const _hoisted_6 = ["src"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "App",
  setup(__props) {
    const { syncStore } = useApp();
    const { theme, direction, posY, setPosY } = useTheme();
    const kitRef = ref();
    const { y, isDragging } = useDraggable(kitRef, {
      axis: "y",
      onEnd: ({ y: y2 }) => {
        setPosY(y2);
      }
    });
    const { height } = useWindowSize();
    const activeTipStyle = computed(() => {
      let fix = 68;
      if (height.value * 0.8 < y.value) {
        fix = -18;
      }
      return { top: y.value ? `${y.value + fix}px` : `calc(38% + ${fix}px)` };
    });
    watch(
      () => posY.value,
      (val) => {
        y.value = val;
      },
      {
        immediate: true
      }
    );
    const { contentApps, contentInnerApps } = useApp();
    const logoUrl = chrome.runtime.getURL(logo);
    const lastPosY = ref();
    const catchPos = () => {
      lastPosY.value = y.value;
    };
    const isActive = ref(false);
    const isVisable = ref(false);
    let openTimer;
    let leaveTimer;
    const clickToolBar = (payload) => {
      if (openTimer)
        clearTimeout(openTimer);
      if (payload.button !== 0)
        return;
      setTimeout(() => {
        const gap = Math.abs(lastPosY.value - y.value) < 10;
        if (gap)
          isActive.value = !isActive.value;
      }, 0);
    };
    const hoverToolBar = () => {
      clearTimeout(openTimer);
      clearTimeout(leaveTimer);
      if (isDragging.value)
        return;
      openTimer = setTimeout(() => {
        isActive.value = true;
        clearTimeout(openTimer);
      }, 1e3);
    };
    watchEffect(() => {
      if (isActive.value) {
        syncStore();
      }
    });
    const leaveToolBar = (isBar = false) => {
      if (!isBar && isActive.value || isDragging.value)
        return;
      clearTimeout(openTimer);
      leaveTimer = setTimeout(() => {
        isActive.value = false;
        clearTimeout(leaveTimer);
      }, 800);
    };
    const current = ref();
    const openPage = (code, url, extra = {}) => {
      injectPostMessage({
        from: Message.Form.INJECT_MESSAGE,
        to: Message.Target.CONTENT,
        code,
        data: {
          openUrl: url,
          extra
        }
      });
    };
    const openLogin = () => {
      openPage("onOpenWindow", "login.html", {
        focused: true,
        width: 500,
        height: 680,
        left: 400,
        top: 100,
        type: "panel"
      });
    };
    const appClick = async (tool) => {
      var _a;
      if (tool.linkUrl) {
        openPage("onOpenChromeUrl", "setting.html");
        return;
      }
      if (((_a = current.value) == null ? void 0 : _a.name) && tool.name !== current.value.name) {
        isVisable.value = true;
      } else
        isVisable.value = !isVisable.value;
      if (isVisable.value)
        current.value = tool;
      else
        current.value = null;
    };
    watch(
      () => isDragging.value,
      () => {
        clearTimeout(openTimer);
        clearTimeout(leaveTimer);
      }
    );
    provide("appContent", {
      setDialog: (val) => {
        isVisable.value = val;
      },
      openPage,
      openLogin
    });
    watchEffect(() => {
      if (!isVisable.value) {
        current.value = void 0;
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["dev-tester-app z-index", [unref(theme)]]),
        style: { "display": "none" }
      }, [
        createBaseVNode("div", {
          ref_key: "kitRef",
          ref: kitRef,
          class: normalizeClass(["kit-tool-warper", [`${unref(direction)}-kit`]]),
          style: normalizeStyle({ top: unref(y) ? `${unref(y)}px` : `38%` })
        }, [
          createBaseVNode("div", {
            class: normalizeClass(["kit-tool", [{ "tool-active": unref(isDragging) }]]),
            onMouseenter: hoverToolBar,
            onMouseleave: _cache[0] || (_cache[0] = () => leaveToolBar()),
            onMousedown: catchPos,
            onMouseup: clickToolBar
          }, [
            createBaseVNode("img", {
              draggable: "false",
              class: "app-logo",
              src: unref(logoUrl),
              alt: "logo"
            }, null, 8, _hoisted_1)
          ], 34)
        ], 6),
        createBaseVNode("div", {
          class: normalizeClass(["dev-tester-kit", [`${unref(direction)}-mode`]]),
          onMouseenter: hoverToolBar,
          onMouseleave: _cache[1] || (_cache[1] = () => leaveToolBar(true))
        }, [
          createBaseVNode("div", {
            class: normalizeClass(["dev-tester-tool-bar", {
              "dev-tester-active": isActive.value || isVisable.value
            }])
          }, [
            createBaseVNode("div", _hoisted_2, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(contentApps), (app2) => {
                var _a;
                return openBlock(), createBlock(_sfc_main$6, {
                  key: app2.name,
                  title: app2.title,
                  logo: app2.logo,
                  active: app2.name === ((_a = current.value) == null ? void 0 : _a.name),
                  onClick: ($event) => appClick(app2)
                }, null, 8, ["title", "logo", "active", "onClick"]);
              }), 128))
            ]),
            createBaseVNode("div", _hoisted_3, [
              _hoisted_4,
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(contentInnerApps), (innerApp) => {
                return openBlock(), createElementBlock("div", {
                  key: innerApp.name,
                  class: "footer-operate btn m-t-1",
                  onClick: ($event) => appClick(innerApp)
                }, [
                  createBaseVNode("img", {
                    src: innerApp.logo
                  }, null, 8, _hoisted_6)
                ], 8, _hoisted_5);
              }), 128))
            ])
          ], 2)
        ], 34),
        createBaseVNode("div", {
          class: normalizeClass(["dev-tester-action", [`${unref(direction)}-action`]]),
          style: normalizeStyle(activeTipStyle.value)
        }, [
          !isVisable.value && !isActive.value ? (openBlock(), createBlock(_sfc_main$1, { key: 0 })) : createCommentVNode("", true)
        ], 6),
        createVNode(_sfc_main$2, {
          modelValue: isVisable.value,
          "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isVisable.value = $event),
          direction: unref(direction),
          tool: current.value
        }, null, 8, ["modelValue", "direction", "tool"])
      ], 2);
    };
  }
});
const APP_SELCTOR = "dev-tester-extension";
const initInject = () => {
  var _a;
  const isExist = document.querySelector(`#${APP_SELCTOR}`);
  if (isExist)
    return true;
  const container = document.createElement("div");
  container.id = `${APP_SELCTOR}`;
  setTimeout(() => {
    var _a2;
    return (_a2 = document.body) == null ? void 0 : _a2.appendChild(container);
  }, 0);
  const root = document.createElement("div");
  root.id = `${APP_SELCTOR}-root`;
  const shadowDOM = (_a = container.attachShadow) == null ? void 0 : _a.call(container, { mode: "open" });
  {
    const styleEl = document.createElement("link");
    styleEl.setAttribute("rel", "stylesheet");
    styleEl.setAttribute(
      "href",
      chrome.runtime.getURL("/assets/shadow-styles.css")
    );
    shadowDOM.appendChild(styleEl);
  }
  shadowDOM.appendChild(root);
  const app2 = createApp$1(_sfc_main);
  contentInstall(app2);
  app2.mount(root);
};
const removeInject = () => {
  var _a, _b;
  const app2 = (_a = document.body) == null ? void 0 : _a.querySelector(`#${APP_SELCTOR}`);
  app2 && ((_b = app2.parentNode) == null ? void 0 : _b.removeChild(app2));
};
const { bubble } = useTheme();
const initContent = () => {
  initInject();
  const timer = setTimeout(() => {
    const isExist = initInject();
    if (isExist)
      clearTimeout(timer);
  }, 100);
};
if (bubble.value) {
  initContent();
} else {
  removeInject();
}
watch(
  () => bubble.value,
  (value) => {
    if (value) {
      initContent();
    } else {
      removeInject();
    }
  }
);
injectCustomScript(injectScript);
const contentInit = () => {
  sendMessageToExtension({
    from: Message.Form.CONTENT_MESSAGE,
    to: Message.Target.SERVERWORKER,
    code: "onContentInit",
    data: {
      url: window.location.href
    }
  });
};
contentInit();
window.addEventListener("load", () => {
  sendMessageToExtension({
    from: Message.Form.CONTENT_MESSAGE,
    to: Message.Target.SERVERWORKER,
    code: "onDocLoad",
    data: { url: window.location.href }
  });
});
window.addEventListener("pageshow", () => {
  sendMessageToExtension({
    from: Message.Form.CONTENT_MESSAGE,
    to: Message.Target.SERVERWORKER,
    code: "onPageshow",
    data: { url: window.location.href }
  });
});
window.addEventListener("message", async (info) => {
  const { data } = info;
  if (data.from !== Message.Form.INJECT_MESSAGE)
    return;
  if (data.code === "onDocVisibilitychange") {
    if (data.data && data.data.visible) {
      initInject();
    }
  }
  sendMessageToExtension({
    ...data,
    from: Message.Form.CONTENT_MESSAGE,
    to: Message.Target.SERVERWORKER
  });
});
window.addEventListener("blur", () => {
  sendMessageToExtension({
    from: Message.Form.CONTENT_MESSAGE,
    to: Message.Target.SERVERWORKER,
    code: "onContentBlur",
    data: { url: window.location.href }
  });
});
window.addEventListener("focus", () => {
  const url = window.location.href;
  const title = document.title;
  const favIconUrl = getFaviconUrl();
  sendMessageToExtension({
    from: Message.Form.CONTENT_MESSAGE,
    to: Message.Target.SERVERWORKER,
    code: "onContentFocus",
    data: { url, title, favIconUrl }
  });
});
chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
  const { code, data } = request;
  if (code === "ContentCore") {
    contentCore(data);
  } else {
    const funcCall = contentFunc[code];
    if (funcCall) {
      funcCall(data);
    }
  }
  sendResponse();
  return false;
});
