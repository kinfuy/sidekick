var _a, _b;
import { W as createtab, X as getChromeUrl, b as createWindow, R as useApp, Y as apps, S as StorageKit, Z as chromeAddListenerMessage } from "./useApp-9e3cc9f6.js";
import { u as useAuth } from "./useAuth-20edcfcc.js";
import "./message-d1775bf2.js";
const PreCoreApp = () => {
  return {
    name: "pre-core-app",
    onAlarms: (opt) => {
      if (opt.name === "refresh-token") {
        const { getRefreshToken } = useAuth();
        getRefreshToken();
      }
    }
  };
};
const SuffixCoreApp = () => {
  return {
    name: "suffix-core-app",
    onOpenChromeUrl: ({ openUrl, extra }) => {
      createtab(getChromeUrl(openUrl), extra);
    },
    onOpenWindow: ({ openUrl, extra }) => {
      createWindow(getChromeUrl(openUrl), extra);
    }
  };
};
const getApplicationHooks = async (name, isActived, limitApp) => {
  const applicationHook = [];
  const { isAppActive } = useApp();
  apps.filter((a) => limitApp ? limitApp.includes(a.name) : true).forEach((app) => {
    const active = isActived ? isAppActive(app.name) : true;
    if (app.hooks[name] && active) {
      applicationHook.push(app.hooks[name]);
    }
  });
  return applicationHook;
};
const runCoreHook = async (name, app, options) => {
  const core = app();
  const coreHooks = core[name];
  if (coreHooks) {
    await coreHooks(options);
  }
};
const triggerApplicationHooks = async (name, options, limitApp) => {
  await runCoreHook(name, PreCoreApp, options);
  const actived = name !== "onActiveChange";
  const hooks = await getApplicationHooks(name, actived, limitApp);
  for (const hook of hooks) {
    await hook(options);
  }
  await runCoreHook(name, SuffixCoreApp, options);
};
const STORE_KEY = "AppAlarm";
const defaultStore = () => {
  return { alarms: [], enabled: false };
};
const useAlarm = () => {
  const storageKit = StorageKit.getInstance(
    STORE_KEY,
    defaultStore()
  );
  const add2 = async (name, alarmInfo) => {
    while (!storageKit.inited) {
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    storageKit.storeRaw.value.alarms.push({ name, alarmInfo });
    storageKit.save();
    return chrome.alarms.create(name, alarmInfo);
  };
  const remove = (name) => {
    var _a2;
    storageKit.storeRaw.value.alarms = (_a2 = storageKit.store.alarms) == null ? void 0 : _a2.filter(
      (n) => n.name !== name
    );
    storageKit.save();
    return chrome.alarms.clear(name);
  };
  return {
    add: add2,
    remove
  };
};
chrome.runtime.onInstalled.addListener(() => {
  triggerApplicationHooks("onInstalled");
});
chrome.tabs.onActivated.addListener(
  (opt) => {
    triggerApplicationHooks("onTabActiveChange", opt);
  }
);
triggerApplicationHooks("onInit");
chromeAddListenerMessage(async (message) => {
  var _a2, _b2;
  let limitApp;
  if (message.code === "onActiveChange" && ((_a2 = message.data) == null ? void 0 : _a2.name)) {
    limitApp = [(_b2 = message.data) == null ? void 0 : _b2.name];
  }
  const contentActive = [
    "onContentInit",
    "onUrlChange",
    "onTabUpdate",
    "onPageshow",
    "onDocVisibilitychange",
    "onDocDOMContentLoaded"
  ];
  if (contentActive.includes(message.code)) {
    triggerApplicationHooks("onContentActive", message.data, limitApp);
  }
  triggerApplicationHooks(message.code, message.data, limitApp);
});
(_a = chrome.alarms) == null ? void 0 : _a.onAlarm.addListener((opt) => {
  triggerApplicationHooks("onAlarms", opt);
});
(_b = chrome.contextMenus) == null ? void 0 : _b.onClicked.addListener((e, tab) => {
  triggerApplicationHooks("onContextMenusClick", { e, tab });
});
chrome.tabs.onUpdated.addListener((...opt) => {
  triggerApplicationHooks("onTabUpdate", opt);
});
chrome.tabs.onCreated.addListener((...opt) => {
  triggerApplicationHooks("onTabCreate", opt);
});
chrome.tabs.onRemoved.addListener((...opt) => {
  triggerApplicationHooks("onTabRemove", opt);
});
chrome.tabs.onMoved.addListener((...opt) => {
  triggerApplicationHooks("onTabMove", opt);
});
chrome.tabs.onReplaced.addListener((...opt) => {
  triggerApplicationHooks("onTabReplaced", opt);
});
const { add } = useAlarm();
add("refresh-token", { periodInMinutes: 60 * 24 });
