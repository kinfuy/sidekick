import { S as StorageKit, T as computed } from "./useApp-9e3cc9f6.js";
const baseURL = "https://api.kinfuy.cn";
const requestInterceptors = (url, data) => {
  const headers = {
    "Content-Type": "application/json"
  };
  const { accessToken } = useAuth();
  if (accessToken.value) {
    headers.Authorization = `Bearer ${accessToken.value}`;
  }
  return {
    url: `${baseURL}${url}`,
    method: "POST",
    headers,
    body: JSON.stringify(data)
  };
};
const responseInterceptors = async (data) => {
  const { clearAuth } = useAuth();
  const rst = await data.json();
  if (rst.code === "000000") {
    return rst == null ? void 0 : rst.data;
  }
  if (rst.code === "100001") {
    throw new Error(rst.message);
  }
  if (rst.code === "100004") {
    clearAuth();
    throw new Error(rst.message);
  }
  throw new Error(rst.message);
};
const myFetch = async (url, data) => {
  const { url: _url, method, headers, body } = requestInterceptors(url, data);
  const rst = await fetch(_url, { method, headers, body });
  return await responseInterceptors(rst);
};
const request = {
  post: async (url, data) => {
    return await myFetch(url, data);
  },
  get: async (url, data) => {
    return await myFetch(url, data);
  }
};
const loginApi = async (data) => {
  return await request.post(`/login`, data);
};
const registerApi = async (data) => {
  return await request.post(`/register`, data);
};
const sendCodeApi = async (data) => {
  return await request.post(`/sendCode`, data);
};
const verifyEmailApi = async (data) => {
  return await request.post(`/verifyEmail`, data);
};
const activationVipApi = async (data) => {
  return await request.post(`/user/activationVip`, data);
};
const refreshTokenApi = async (data) => {
  return await request.post(`/refreshToken`, data);
};
const STORE_KEY = "AppAuth";
const defaultStore = () => {
  return { isLogin: false };
};
const useAuth = () => {
  const storageKit = StorageKit.getInstance(
    STORE_KEY,
    defaultStore()
  );
  const isLogin = computed(() => storageKit.store.isLogin);
  const user = computed(() => {
    return storageKit.store.user;
  });
  const subscription = computed(() => {
    const { user: user2 } = storageKit.store;
    if (user2 == null ? void 0 : user2.subscription) {
      switch (user2.subscription.type) {
        case 1:
          return {
            ...user2 == null ? void 0 : user2.subscription,
            name: "月卡会员"
          };
        case 2:
          return {
            ...user2 == null ? void 0 : user2.subscription,
            name: "季卡会员"
          };
        case 3:
          return {
            ...user2 == null ? void 0 : user2.subscription,
            name: "年卡会员"
          };
        case 4:
          return {
            ...user2 == null ? void 0 : user2.subscription,
            name: "周体验卡"
          };
        case 99:
          return {
            ...user2 == null ? void 0 : user2.subscription,
            name: "永久会员"
          };
      }
    }
    return null;
  });
  const accessToken = computed(() => {
    const { user: user2 } = storageKit.store;
    if (user2)
      return user2.accessToken;
    return null;
  });
  const refreshToken = computed(() => {
    const { user: user2 } = storageKit.store;
    if (user2)
      return user2.refreshToken;
    return null;
  });
  const setUser = (user2) => {
    storageKit.storeRaw.value = {
      user: user2,
      isLogin: true,
      lastLoginTime: /* @__PURE__ */ new Date()
    };
    storageKit.save();
  };
  const setSubscription = (subscription2) => {
    storageKit.storeRaw.value.user.subscription = subscription2;
    storageKit.save();
  };
  const clearAuth = () => {
    storageKit.clear();
  };
  const getRefreshToken = async () => {
    if (isLogin.value) {
      const res = await refreshTokenApi({
        refreshToken: storageKit.store.user.refreshToken,
        accessToken: storageKit.store.user.accessToken
      });
      if (res) {
        storageKit.storeRaw.value.user.accessToken = res.accessToken;
        storageKit.storeRaw.value.user.refreshToken = res.refreshToken;
        storageKit.save();
      } else {
        clearAuth();
      }
    }
  };
  return {
    isLogin,
    user,
    subscription,
    accessToken,
    refreshToken,
    setUser,
    clearAuth,
    setSubscription,
    getRefreshToken
  };
};
export {
  activationVipApi as a,
  loginApi as l,
  registerApi as r,
  sendCodeApi as s,
  useAuth as u,
  verifyEmailApi as v
};
