import { v as vModelDynamic } from "./useTheme-a51fa13a.js";
import { d as defineComponent, r as ref, w as watch, e as createVNode, f as createTextVNode, g as withDirectives } from "./useApp-9e3cc9f6.js";
const logo = "/assets/logo.png";
const Sinput = /* @__PURE__ */ defineComponent({
  name: "SInput",
  props: {
    label: {
      type: String,
      default: ""
    },
    type: {
      type: String,
      default: "text"
    },
    labelWidth: {
      type: String,
      default: "48px"
    },
    modelValue: {
      type: String,
      default: ""
    },
    placeholder: {
      type: String,
      default: ""
    }
  },
  emits: ["update:modelValue", "change", "blur", "focus"],
  setup(props, {
    emit
  }) {
    const stateValue = ref("");
    watch(() => props.modelValue, (value) => {
      stateValue.value = value;
    }, {
      immediate: true
    });
    const handleChange = () => {
      emit("update:modelValue", stateValue.value);
      emit("change", stateValue.value);
    };
    const emitEvent = (event) => {
      emit(event, stateValue.value);
    };
    return {
      stateValue,
      emitEvent,
      handleChange
    };
  },
  render() {
    return createVNode("div", {
      "class": "ui-filed"
    }, [this.label && createVNode("span", {
      "class": "ui-filed-label",
      "style": {
        width: this.labelWidth
      }
    }, [this.label, createTextVNode(":")]), withDirectives(createVNode("input", {
      "type": this.type,
      "onUpdate:modelValue": ($event) => this.stateValue = $event,
      "placeholder": this.placeholder,
      "onBlur": this.emitEvent.bind(this, "blur"),
      "onFocus": this.emitEvent.bind(this, "focus"),
      "onChange": this.handleChange
    }, null), [[vModelDynamic, this.stateValue]])]);
  }
});
export {
  Sinput as S,
  logo as l
};
