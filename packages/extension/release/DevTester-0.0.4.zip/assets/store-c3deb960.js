import { u as uuid } from "./util-9e04540b.js";
import { r as ref, S as StorageKit, T as computed, d as defineComponent, e as createVNode } from "./useApp-9e3cc9f6.js";
const getElementByXpath = (xpath) => {
  const result = document.evaluate(
    xpath,
    document,
    null,
    XPathResult.ANY_TYPE,
    null
  );
  return result.iterateNext();
};
const camelize = (str) => {
  return str.replace(
    /(?:^\w|[A-Z]|\b\w|\s+)/g,
    function(match, index) {
      if (+match === 0)
        return "";
      return index === 0 ? match.toLowerCase() : match.toUpperCase();
    }
  );
};
const getStyle = (element, styleName, isComputed) => {
  var _a;
  if (!element || !styleName)
    return "";
  let name = camelize(styleName);
  if (name === "float") {
    name = "cssFloat";
  }
  try {
    const style = element.style[name];
    if (style)
      return style;
    const computed2 = isComputed ? (_a = document.defaultView) == null ? void 0 : _a.getComputedStyle(element, "") : element.style;
    return computed2 ? computed2[name] : "";
  } catch (e) {
    return element.style[name];
  }
};
const setStyle = (element, styles) => {
  if (!element)
    return;
  Object.keys(styles).forEach((styleName) => {
    const styleValue = styles[styleName];
    element.style[camelize(styleName)] = styleValue;
  });
};
const dispatchEventHandler = (eventName, el, config) => {
  if (el || eventName === "keyup" || eventName === "keydown") {
    switch (eventName) {
      case "click": {
        const clickEvent = new Event("click", {
          cancelable: true,
          bubbles: true
        });
        el.dispatchEvent(clickEvent);
        break;
      }
      case "submit": {
        const clickEvent = new SubmitEvent("submit", {
          cancelable: true,
          bubbles: true
        });
        el.dispatchEvent(clickEvent);
        break;
      }
      case "focus":
        el.focus();
        break;
      case "blur": {
        el.blur();
        break;
      }
      case "input":
        {
          const inputEvent = new InputEvent("input", {
            data: config == null ? void 0 : config.data,
            bubbles: true,
            cancelable: true
          });
          el.dispatchEvent(inputEvent);
        }
        break;
      case "change": {
        const changeEvent = new InputEvent("change", {
          data: config == null ? void 0 : config.data,
          bubbles: true,
          cancelable: true
        });
        el.dispatchEvent(changeEvent);
        break;
      }
      case "mousedown": {
        const mouseEvent = new MouseEvent("mousedown", {
          bubbles: true,
          cancelable: true,
          view: window
        });
        el.dispatchEvent(mouseEvent);
        break;
      }
      case "keyup": {
        if (config && config.keyboardConfig) {
          const keyboardEvent = new KeyboardEvent("keyup", {
            ...config.keyboardConfig,
            location: 1,
            bubbles: true,
            cancelable: true,
            composed: true
          });
          document.body.dispatchEvent(keyboardEvent);
        }
        break;
      }
      case "keydown": {
        if (config && config.keyboardConfig) {
          const keyboardEvent = new KeyboardEvent("keydown", {
            ...config.keyboardConfig,
            shiftKey: config.keyboardConfig.keyCode === 16,
            altKey: config.keyboardConfig.keyCode === 18,
            location: 1,
            bubbles: true,
            cancelable: true,
            composed: true
          });
          document.body.dispatchEvent(keyboardEvent);
        }
        break;
      }
      case "mouseup": {
        const mouseEvent = new MouseEvent("mouseup", {
          bubbles: true,
          cancelable: true,
          view: window
        });
        el.dispatchEvent(mouseEvent);
        break;
      }
      default:
        if (config && config.mouseEventConfig) {
          const event = new MouseEvent(eventName, {
            ...config.mouseEventConfig,
            bubbles: true,
            cancelable: true
          });
          el.dispatchEvent(event);
        } else {
          const event = new MouseEvent(eventName, {
            bubbles: true,
            cancelable: true
          });
          el.dispatchEvent(event);
        }
    }
  }
};
const getAllStorage = (storage) => {
  const len = storage.length;
  const arr = [];
  for (let i = 0; i < len; i++) {
    const getKey = storage.key(i);
    if (getKey) {
      const getVal = storage.getItem(getKey);
      arr[i] = {
        key: getKey,
        val: getVal == null ? void 0 : getVal.trim()
      };
    }
  }
  return arr;
};
const transformUrl = (url) => {
  if (url.startsWith("https://") || url.startsWith("http://")) {
    return new URL(url).host;
  }
  return new URL(`https://${url}`).host;
};
const getFaviconUrl = () => {
  const links = document.getElementsByTagName("link");
  for (let i = 0; i < links.length; i++) {
    if (links[i].rel.match(/icon|shortcut icon/i)) {
      return links[i].href;
    }
  }
  return null;
};
const defaultMatchRule = {
  account: {
    xpath: [],
    placeholder: ["手机", "用户", "账户", "登陆名", "账号"],
    cssSeletor: []
  },
  password: {
    xpath: [],
    placeholder: ["密码"],
    cssSeletor: []
  },
  loginBtn: {
    xpath: [],
    placeholder: [],
    cssSeletor: [".login-btn"]
  },
  validate: {
    xpath: [],
    placeholder: ["验证码"],
    cssSeletor: []
  }
};
const STORE_KEY$4 = "DevAccount";
const matchWeb = ref();
const defaultStore$4 = {
  webs: [],
  version: "1.0.0"
};
const useDevAccountStore = () => {
  const storageKit = StorageKit.getInstance(
    STORE_KEY$4,
    defaultStore$4
  );
  const addOrUpdateWeb = (rawWeb) => {
    const web = JSON.parse(JSON.stringify(rawWeb));
    if (web.id) {
      const index = storageKit.store.webs.findIndex((w) => w.id === rawWeb.id);
      if (index > -1) {
        storageKit.storeRaw.value.webs[index] = {
          ...storageKit.store.webs[index],
          ...web
        };
      }
    } else {
      storageKit.storeRaw.value.webs.push({
        id: uuid(),
        name: web.name || "",
        isActive: web.isActive ?? true,
        autoLogin: web.autoLogin ?? true,
        code: web.code ?? "code",
        match: web.match ?? defaultMatchRule,
        envs: web.envs ?? [],
        users: web.users ?? []
      });
    }
    storageKit.save();
  };
  const removeWeb = (id) => {
    storageKit.storeRaw.value.webs = storageKit.store.webs.filter(
      (w) => w.id !== id
    );
    storageKit.save();
  };
  const removeUser = (webId, userId) => {
    var _a, _b;
    (_b = (_a = storageKit.storeRaw.value.webs.find((w) => w.id === webId)) == null ? void 0 : _a.users) == null ? void 0 : _b.filter((u) => u.id !== userId);
    storageKit.save();
  };
  const removeEnv = (webId, useId) => {
    var _a, _b;
    (_b = (_a = storageKit.storeRaw.value.webs.find((w) => w.id === webId)) == null ? void 0 : _a.envs) == null ? void 0 : _b.filter((u) => u.id !== useId);
    storageKit.save();
  };
  const activeWebs = computed(() => {
    return storageKit.store.webs.filter((w) => w.isActive);
  });
  const webs = computed(() => {
    return storageKit.store.webs;
  });
  const setMatch = (web) => {
    if (!web) {
      matchWeb.value = void 0;
      return;
    }
    matchWeb.value = storageKit.store.webs.find((w) => w.name === web);
  };
  const getMatch = async (url) => {
    while (!storageKit.inited) {
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    return storageKit.store.webs.find((web) => {
      var _a;
      if ((_a = web.envs) == null ? void 0 : _a.some((u) => url.includes(u.url)))
        return true;
      return false;
    });
  };
  const exportConfig = () => {
    return storageKit.store;
  };
  const importConfig = (config, type) => {
    if (type === "replace") {
      storageKit.storeRaw.value = config;
    }
    if (type === "update") {
      const webs2 = [];
      storageKit.store.webs.forEach((w) => {
        const web = config.webs.find((x) => x.id === w.id);
        if (web) {
          webs2.push({ ...w, ...web });
        } else {
          webs2.push(w);
        }
      });
      config.webs.forEach((w) => {
        const web = webs2.find((x) => x.id === w.id);
        if (!web) {
          webs2.push(w);
        }
      });
      storageKit.storeRaw.value.version = config.version;
      storageKit.storeRaw.value.webs = webs2;
    }
    storageKit.save();
  };
  const version = computed(() => {
    return storageKit.store.version;
  });
  return {
    version,
    webs,
    addOrUpdateWeb,
    matchWeb,
    setMatch,
    getMatch,
    activeWebs,
    removeWeb,
    removeUser,
    removeEnv,
    exportConfig,
    importConfig
  };
};
const empty = "/assets/empty.svg";
const Empty = /* @__PURE__ */ defineComponent({
  name: "Empty",
  props: {
    img: {
      type: String,
      default: chrome.runtime.getURL(empty)
    },
    onlyText: {
      type: Boolean,
      default: false
    },
    text: {
      type: String,
      default: "暂无数据"
    }
  },
  render() {
    return createVNode("div", {
      "class": "empty-view"
    }, [!this.onlyText ? createVNode("img", {
      "class": "empty-img",
      "src": this.img
    }, null) : null, this.text ? createVNode("span", {
      "class": "empty-text"
    }, [this.text]) : null, this.$slots.default && this.$slots.default()]);
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const defaultStore$3 = () => ({
  whiteList: [],
  current: void 0,
  viewType: "border"
});
const STORE_KEY$3 = "WebNotice";
const useWebNoticeStore = () => {
  const storageKit = StorageKit.getInstance(
    STORE_KEY$3,
    defaultStore$3()
  );
  const whiteList = computed(() => {
    return storageKit.store.whiteList;
  });
  const viewType = computed(() => {
    return storageKit.store.viewType;
  });
  const current = computed(() => {
    return storageKit.store.current;
  });
  const setCurrent = async (url) => {
    var _a;
    await storageKit.sync();
    while (!storageKit.inited) {
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    storageKit.storeRaw.value.current = (_a = storageKit.store.whiteList) == null ? void 0 : _a.find(
      (web) => {
        if (url.includes(web.url))
          return true;
        return false;
      }
    );
    storageKit.save();
    return storageKit.store.current;
  };
  const serViewType = (val) => {
    storageKit.store.viewType = val;
  };
  const updateWeb = (web) => {
    var _a, _b, _c;
    if ((_b = (_a = storageKit.storeRaw.value) == null ? void 0 : _a.whiteList) == null ? void 0 : _b.some((x) => x.url === web.url)) {
      storageKit.storeRaw.value.whiteList.forEach((w) => {
        if (w.url === web.url) {
          w.active = web.active;
          w.tips = web.tips;
          w.style = web.style;
        }
      });
    } else {
      if (!((_c = storageKit.storeRaw.value) == null ? void 0 : _c.whiteList))
        storageKit.storeRaw.value.whiteList = [];
      storageKit.storeRaw.value.whiteList.push({ ...web });
    }
    storageKit.storeRaw.value.current = { ...web };
    storageKit.save();
  };
  const removeWeb = (url) => {
    storageKit.storeRaw.value.whiteList = storageKit.store.whiteList.filter(
      (w) => w.url !== url
    );
    storageKit.save();
  };
  const clear = () => {
    storageKit.clear();
  };
  return {
    whiteList,
    current,
    setCurrent,
    viewType,
    clear,
    serViewType,
    updateWeb,
    removeWeb
  };
};
const STORE_KEY$2 = "LinkGo";
const defaultStore$2 = () => {
  return {
    linkRules: [
      {
        type: "string",
        value: "target",
        description: "http://xxx.cn?target=https://devtester.kinfuy.cn => https://devtester.kinfuy.cn"
      },
      {
        type: "string",
        value: "url",
        description: "https://xxx.cn?url=https://devtester.kinfuy.cn => https://devtester.kinfuy.cn"
      },
      {
        type: "regex",
        value: "transfer?(?<target>.+)",
        // https://blog.51cto.com/
        description: "https://www.xxx.com/transfer?https://devtester.kinfuy.cn => https://devtester.kinfuy.cn"
      }
    ]
  };
};
const useLinkGoStore = () => {
  const storageKit = StorageKit.getInstance(
    STORE_KEY$2,
    defaultStore$2()
  );
  const addRule = async (rule) => {
    const isexist = storageKit.store.linkRules.find(
      (r) => r.type === rule.type && r.value === rule.value
    );
    if (isexist)
      return false;
    storageKit.storeRaw.value.linkRules.push(JSON.parse(JSON.stringify(rule)));
    storageKit.save();
    return true;
  };
  const setRules = async (rules2) => {
    storageKit.storeRaw.value.linkRules = rules2;
    storageKit.save();
  };
  const removeRule = async (rule) => {
    storageKit.storeRaw.value.linkRules = storageKit.store.linkRules.filter(
      (r) => !(r.type === rule.type && r.value === rule.value)
    );
    storageKit.save();
  };
  const rules = computed(() => {
    return storageKit.store.linkRules;
  });
  const parseUrl = (url, filed) => {
    if (filed.type === "string") {
      const urlObject = new URL(url);
      const urlParamRes = urlObject.searchParams.get(filed.value);
      return urlParamRes;
    }
    if (filed.type) {
      try {
        const reg = new RegExp(filed.value);
        const match = url.match(reg);
        if ((match == null ? void 0 : match.groups) && match.groups.target) {
          return match == null ? void 0 : match.groups.target.replace(/^\?/, "");
        }
      } catch (error) {
        return void 0;
      }
    }
    return void 0;
  };
  const inited = computed(() => {
    return storageKit.inited;
  });
  return {
    addRule,
    setRules,
    rules,
    parseUrl,
    inited,
    removeRule
  };
};
const defaultStore$1 = () => {
  return {
    status: 0,
    clickCount: 0
  };
};
const STORE_KEY$1 = "ClickCount";
const useClickCountStore = () => {
  const storageKit = StorageKit.getInstance(
    STORE_KEY$1,
    defaultStore$1()
  );
  const status = computed(() => {
    return storageKit.store.status;
  });
  const count = computed(() => {
    return storageKit.store.clickCount;
  });
  const add = async (count2 = 1) => {
    storageKit.storeRaw.value.clickCount += count2;
    await storageKit.save();
  };
  const set = (val) => {
    if (val === 0) {
      storageKit.storeRaw.value.status = 0;
      storageKit.storeRaw.value.clickCount = 0;
    }
    storageKit.storeRaw.value.status = val;
    storageKit.save();
  };
  return {
    status,
    count,
    add,
    set
  };
};
const STORE_KEY = "UrlBlock";
const defaultStore = () => {
  return {
    engines: [
      {
        engine: "google",
        url: {
          type: "string",
          value: "google.com"
        },
        query: {
          target: {
            selector: "cite",
            path: "firstChild.nodeValue"
          },
          container: ".MjjYud"
        }
      },
      {
        engine: "baidu",
        url: {
          type: "string",
          value: "baidu.com"
        },
        delay: 2e3,
        query: {
          target: {
            selector: ".result.c-container",
            attribute: "mu"
          },
          container: ".result.c-container"
        }
      },
      {
        engine: "bing",
        url: {
          type: "string",
          value: "bing.com"
        },
        query: {
          target: {
            selector: "cite",
            path: "firstChild.nodeValue"
          },
          container: ".b_algo"
        }
      },
      {
        engine: "sogou",
        url: {
          type: "string",
          value: "sogou.com"
        },
        query: {
          target: {
            selector: "div.citeurl>span:nth-last-child(2)",
            path: "firstChild.nodeValue"
          },
          container: ".vrwrap"
        }
      },
      {
        engine: "360",
        url: {
          type: "string",
          value: "www.so.com"
        },
        query: {
          target: {
            selector: ".g-linkinfo-a",
            path: "firstChild.nodeValue"
          },
          container: ".res-list"
        }
      }
    ],
    blackList: [
      {
        id: "1",
        title: "CSDN",
        type: "string",
        value: ["blog.csdn.net", "wenku.csdn.net"],
        enable: true
      },
      {
        id: "2",
        title: "腾讯云",
        type: "string",
        value: "cloud.tencent.com",
        enable: true
      },
      {
        id: "3",
        title: "阿里云",
        type: "string",
        value: ["www.aliyun.com", "developer.aliyun.com"],
        enable: true
      }
    ]
  };
};
const useUrlBlockStore = () => {
  const storageKit = StorageKit.getInstance(
    STORE_KEY,
    defaultStore()
  );
  const blackList = computed(() => {
    return storageKit.store.blackList;
  });
  const enableBlackList = computed(() => {
    return storageKit.store.blackList.filter((b) => b.enable);
  });
  const engines = computed(() => {
    return storageKit.store.engines;
  });
  const getEnfineConfig = (url) => {
    for (const engine of storageKit.store.engines) {
      if (engine.url.type === "string") {
        if (Array.isArray(engine.url.value)) {
          if (engine.url.value.includes(url)) {
            return engine;
          }
        } else if (url.includes(engine.url.value)) {
          return engine;
        }
      }
      if (engine.url.type === "regex") {
        if (Array.isArray(engine.url.value)) {
          return engine.url.value.some((v) => url.match(v)) ? engine : void 0;
        } else {
          return url.match(engine.url.value) ? engine : void 0;
        }
      }
    }
  };
  const inited = computed(() => {
    return storageKit.inited;
  });
  const setBlock = async (id, enable) => {
    await storageKit.sync();
    while (!storageKit.inited) {
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    storageKit.storeRaw.value.blackList = storageKit.storeRaw.value.blackList.map((b) => {
      if (b.id === id) {
        b.enable = enable;
      }
      return b;
    });
    storageKit.save();
  };
  const update = async (item) => {
    while (!storageKit.inited) {
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    if (storageKit.storeRaw.value.blackList.some((b) => b.id === item.id)) {
      storageKit.storeRaw.value.blackList = storageKit.storeRaw.value.blackList.map((b) => {
        if (b.id === item.id) {
          b = item;
        }
        return b;
      });
    } else {
      storageKit.storeRaw.value.blackList.push(item);
    }
    storageKit.save();
  };
  return {
    blackList,
    enableBlackList,
    engines,
    inited,
    getEnfineConfig,
    setBlock,
    update
  };
};
export {
  Empty as E,
  _export_sfc as _,
  useDevAccountStore as a,
  useLinkGoStore as b,
  getAllStorage as c,
  dispatchEventHandler as d,
  useClickCountStore as e,
  getStyle as f,
  getElementByXpath as g,
  useUrlBlockStore as h,
  getFaviconUrl as i,
  setStyle as s,
  transformUrl as t,
  useWebNoticeStore as u
};
