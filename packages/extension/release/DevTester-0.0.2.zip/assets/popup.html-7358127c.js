import "./modulepreload-polyfill-7faf532e.js";
import { u as useTheme, c as createApp } from "./useTheme-14845108.js";
import { w as withInstall, C as ConfigProvider, _ as _export_sfc, p as popupInstall } from "./install-de232503.js";
import { _ as _sfc_main$1 } from "./ToolItem.vue_vue_type_script_setup_true_lang-2e582dbb.js";
import { d as defineComponent, g as getChromeUrl, s as set, a as sendMessageToExtension, u as useApp, r as ref, o as onBeforeUnmount, w as watchEffect, p as provide, b as openBlock, c as createBlock, e as withCtx, f as unref, h as createBaseVNode, i as createElementBlock, j as renderList, F as Fragment, k as resolveDynamicComponent, l as createCommentVNode, n as normalizeClass } from "./useAuth-0e8a18b0.js";
/* empty css                */import "./util-9e04540b.js";
const ElConfigProvider = withInstall(ConfigProvider);
const _hoisted_1 = { class: "popup-slider" };
const _hoisted_2 = {
  key: 0,
  class: "popup-content"
};
const _hoisted_3 = ["src"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "popup",
  setup(__props) {
    const setIcon = getChromeUrl(set);
    sendMessageToExtension({
      from: "POPUP_VIEW",
      code: "onPopupOpen",
      data: {}
    });
    const { theme } = useTheme();
    const { popupApps, inited } = useApp();
    const current = ref();
    const appClick = (app2) => {
      current.value = app2;
    };
    onBeforeUnmount(() => {
      sendMessageToExtension({
        from: "POPUP_VIEW",
        code: "onPopupClose",
        data: {}
      });
      current.value = void 0;
    });
    const handleSet = () => {
      var _a;
      const query = current.value ? `#${(_a = current.value) == null ? void 0 : _a.name}` : "";
      window.open(getChromeUrl(`setting.html${query}`), "_blank");
    };
    watchEffect(() => {
      if (popupApps.value.length === 0 && inited.value) {
        handleSet();
        window.close();
      }
      if (popupApps.value.length > 0) {
        current.value = popupApps.value[0];
      }
    });
    provide("appContent", {
      openSet: handleSet
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(ElConfigProvider), { size: "small" }, {
        default: withCtx(() => [
          createBaseVNode("div", {
            class: normalizeClass(["popup-app", [unref(theme)]])
          }, [
            createBaseVNode("div", _hoisted_1, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(popupApps), (app2) => {
                var _a;
                return openBlock(), createBlock(_sfc_main$1, {
                  key: app2.name,
                  title: app2.title,
                  logo: app2.logo,
                  active: app2.name === ((_a = current.value) == null ? void 0 : _a.name),
                  onClick: ($event) => appClick(app2)
                }, null, 8, ["title", "logo", "active", "onClick"]);
              }), 128))
            ]),
            unref(popupApps).length ? (openBlock(), createElementBlock("div", _hoisted_2, [
              createBaseVNode("img", {
                class: "popup-set",
                src: unref(setIcon),
                onClick: handleSet
              }, null, 8, _hoisted_3),
              current.value ? (openBlock(), createBlock(resolveDynamicComponent(`Popup${current.value.name}`), {
                key: current.value.name
              })) : createCommentVNode("", true)
            ])) : createCommentVNode("", true)
          ], 2)
        ]),
        _: 1
      });
    };
  }
});
const popup_vue_vue_type_style_index_0_scoped_19bff626_lang = "";
const popup = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-19bff626"]]);
const index = "";
const app = createApp(popup);
popupInstall(app);
app.mount("#popup-app");
