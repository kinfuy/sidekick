import { d as defineComponent, o as openBlock, c as createElementBlock, a as createBaseVNode, u as unref, b as createWindow } from "./useAuth-a26fa5df.js";
import { i as injectPostMessage } from "./util-9e04540b.js";
import { l as logo } from "./logo-219d4073.js";
const _hoisted_1 = { class: "dev-tester-cover" };
const _hoisted_2 = { class: "logo-content" };
const _hoisted_3 = ["src"];
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("span", { class: "logo-title" }, "DevTester", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("span", null, "欢迎，请点击登录DevTester", -1);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Cover",
  props: {
    isInject: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const props = __props;
    const logoIcon = chrome.runtime.getURL(logo);
    const openPage = (code, url, extra = {}) => {
      injectPostMessage({
        from: "app_inject",
        code,
        data: {
          openUrl: url,
          extra
        }
      });
    };
    const openLogin = () => {
      const config = {
        focused: true,
        width: 500,
        height: 680,
        left: 400,
        top: 100,
        type: "panel"
      };
      if (props.isInject) {
        openPage("onOpenWindow", "login.html", config);
      } else {
        createWindow("login.html", config);
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("div", _hoisted_2, [
          createBaseVNode("img", {
            class: "logo",
            src: unref(logoIcon),
            alt: "logo"
          }, null, 8, _hoisted_3),
          _hoisted_4,
          _hoisted_5,
          createBaseVNode("div", { class: "cover-btn" }, [
            createBaseVNode("span", {
              class: "login-btn",
              onClick: openLogin
            }, "登录")
          ])
        ])
      ]);
    };
  }
});
export {
  _sfc_main as _
};
