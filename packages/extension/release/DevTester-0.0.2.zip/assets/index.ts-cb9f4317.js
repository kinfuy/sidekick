import { i as injectPostMessage } from "./util-9e04540b.js";
document.addEventListener("visibilitychange", () => {
  let visible = false;
  if (document.visibilityState === "visible") {
    visible = true;
  }
  injectPostMessage({
    from: "app_inject",
    code: "onDocVisibilitychange",
    data: { visible }
  });
});
