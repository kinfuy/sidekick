const logo = "/assets/logo.png";
export {
  logo as l
};
