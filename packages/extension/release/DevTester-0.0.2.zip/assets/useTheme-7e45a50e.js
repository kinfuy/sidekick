import { v as vModelDynamic } from "./runtime-dom.esm-bundler-ed55ea30.js";
import { d as defineComponent, M as ref, N as watch, G as createVNode, O as createTextVNode, P as withDirectives, Q as computed, R as onMounted, S as onUnmounted } from "./runtime-core.esm-bundler-8320c277.js";
import { S as StorageKit, u as useApp } from "./useAuth-329dd5dc.js";
const Sinput = /* @__PURE__ */ defineComponent({
  name: "SInput",
  props: {
    label: {
      type: String,
      default: ""
    },
    type: {
      type: String,
      default: "text"
    },
    labelWidth: {
      type: String,
      default: "48px"
    },
    modelValue: {
      type: String,
      default: ""
    },
    placeholder: {
      type: String,
      default: ""
    }
  },
  emits: ["update:modelValue", "change", "blur", "focus"],
  setup(props, {
    emit
  }) {
    const stateValue = ref("");
    watch(() => props.modelValue, (value) => {
      stateValue.value = value;
    }, {
      immediate: true
    });
    const handleChange = () => {
      emit("update:modelValue", stateValue.value);
      emit("change", stateValue.value);
    };
    const emitEvent = (event) => {
      emit(event, stateValue.value);
    };
    return {
      stateValue,
      emitEvent,
      handleChange
    };
  },
  render() {
    return createVNode("div", {
      "class": "ui-filed"
    }, [this.label && createVNode("span", {
      "class": "ui-filed-label",
      "style": {
        width: this.labelWidth
      }
    }, [this.label, createTextVNode(":")]), withDirectives(createVNode("input", {
      "type": this.type,
      "onUpdate:modelValue": ($event) => this.stateValue = $event,
      "placeholder": this.placeholder,
      "onBlur": this.emitEvent.bind(this, "blur"),
      "onFocus": this.emitEvent.bind(this, "focus"),
      "onChange": this.handleChange
    }, null), [[vModelDynamic, this.stateValue]])]);
  }
});
const STORE_KEY = "AppTheme";
const defaultStore = () => ({
  mode: "light",
  direction: "right",
  pos: { y: 100 },
  bubble: true
});
const useTheme = () => {
  const storageKit = StorageKit.getInstance(
    STORE_KEY,
    defaultStore()
  );
  const { contentApps } = useApp();
  const theme = computed(() => storageKit.store.mode);
  const direction = computed(() => storageKit.store.direction);
  const windowHeight = ref(document.documentElement.clientHeight);
  const setHeight = () => {
    windowHeight.value = document.documentElement.clientHeight;
  };
  onMounted(() => {
    window.addEventListener("resize", setHeight);
  });
  onUnmounted(() => {
    window.removeEventListener("resize", setHeight);
  });
  const posY = computed(() => {
    return windowHeight.value < storageKit.store.pos.y ? windowHeight.value - 180 : storageKit.store.pos.y;
  });
  const setDirection = (val) => {
    storageKit.storeRaw.value.direction = val;
    storageKit.save();
  };
  const setTheme = (val) => {
    storageKit.storeRaw.value.mode = val;
    storageKit.save();
  };
  const setPosY = (val) => {
    storageKit.storeRaw.value.pos.y = val;
    storageKit.save();
  };
  const clearTheme = () => {
    storageKit.storeRaw.value = JSON.parse(JSON.stringify(defaultStore));
    storageKit.save();
  };
  const bubble = computed(() => {
    if (contentApps.value.length === 0)
      return false;
    return storageKit.store.bubble;
  });
  const setBubble = (val) => {
    storageKit.storeRaw.value.bubble = val;
    storageKit.save();
  };
  return {
    posY,
    theme,
    direction,
    setTheme,
    setDirection,
    setPosY,
    clearTheme,
    bubble,
    setBubble
  };
};
export {
  Sinput as S,
  useTheme as u
};
