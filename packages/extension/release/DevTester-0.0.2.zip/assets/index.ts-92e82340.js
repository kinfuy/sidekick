import { k as sendMessageToExtension, m as useClickCountStore, a as useAuth, u as useApp, n as injectCustomScript } from "./useAuth-c9de56b9.js";
import { d as dispatchEventHandler, g as getElementByXpath, u as useLinkGoStore, a as getAllStorage, b as useStoragePortalStore, c as createApp, w as webNotice, E as Empty, e as contentInstall } from "./install-20ab9f7b.js";
import { d as defineComponent, M as ref, W as watchEffect, o as openBlock, c as createElementBlock, a as createBaseVNode, O as createTextVNode, V as toDisplayString, u as unref, F as Fragment, X as renderList, Y as normalizeStyle, N as watch, U as createCommentVNode, T as createBlock, Z as resolveDynamicComponent, n as normalizeClass, _ as isRef, $ as toRefs$1, a0 as customRef, a1 as getCurrentScope, a2 as onScopeDispose, Q as computed, a3 as provide, G as createVNode } from "./runtime-core.esm-bundler-1bf05d91.js";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.js";
import { u as useTheme } from "./useTheme-14b4ee4f.js";
import { c as createApp$1 } from "./runtime-dom.esm-bundler-7d86a7cb.js";
import { _ as _sfc_main$3 } from "./Cover.vue_vue_type_script_setup_true_lang-8036a50f.js";
import { _ as _sfc_main$4 } from "./ToolItem.vue_vue_type_script_setup_true_lang-8cdb0d9a.js";
import { i as injectPostMessage } from "./util-9e04540b.js";
import "./logo-219d4073.js";
const elementCssSelector = (css) => {
  let el = null;
  for (let i = 0; i < css.length; i++) {
    try {
      el = document.body.querySelector(css[i]);
    } catch (error) {
    }
    if (el)
      break;
  }
  return el;
};
const elementXPath = (xpath) => {
  let el = null;
  for (let i = 0; i < xpath.length; i++) {
    try {
      el = getElementByXpath(xpath[i]);
    } catch (error) {
    }
    if (el)
      break;
  }
  return el;
};
const elementPlaceholder = (placeholder) => {
  let el = null;
  for (let i = 0; i < placeholder.length; i++) {
    try {
      el = document.querySelector(
        `input[placeholder*="${placeholder[i]}"]`
      );
    } catch (error) {
    }
    if (el)
      break;
  }
  return el;
};
const getElement = (config) => {
  let el = null;
  if (config.cssSeletor) {
    el = elementCssSelector(config.cssSeletor);
  }
  if (!el && config.placeholder) {
    el = elementPlaceholder(config.placeholder);
  }
  if (!el && config.xpath) {
    el = elementXPath(config.xpath);
  }
  return el;
};
const autoInput = (userInfo) => {
  const { account, password, validate, loginBtn } = userInfo.rules;
  const { autoLogin, code } = userInfo.options;
  const userEl = getElement(account);
  const passWordEl = getElement(password);
  const validateEl = getElement(validate);
  const loginEle = getElement(loginBtn);
  if (userEl && passWordEl) {
    userEl.value = userInfo.user.name;
    dispatchEventHandler("input", userEl);
    passWordEl.value = userInfo.user.password;
    dispatchEventHandler("input", passWordEl);
    if (validateEl) {
      validateEl.value = code || "";
      dispatchEventHandler("input", validateEl);
    }
    if (autoLogin && loginEle) {
      dispatchEventHandler("mousedown", loginEle);
      dispatchEventHandler("mouseup", loginEle);
      dispatchEventHandler("click", loginEle);
      dispatchEventHandler("submit", loginEle);
    }
  }
};
const devAccount = (option) => {
  const { key } = option;
  const { web, user } = option.data;
  if (key === "user-login" && user) {
    autoInput({
      user,
      rules: web.match,
      options: {
        code: web.code,
        autoLogin: web.autoLogin
      }
    });
  }
};
const { rules, parseUrl, inited } = useLinkGoStore();
const linkGo = async () => {
  while (!inited.value) {
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  const url = window.location.href;
  let href;
  for (let i = 0; i < rules.value.length; i++) {
    href = parseUrl(url, rules.value[i]);
    if (href)
      break;
  }
  if (href)
    window.location.href = new URL(href).href;
};
const storagePortal = (opt) => {
  if (opt.key === "send-storage") {
    const _localStorage = getAllStorage(localStorage);
    const _sessionStorage = getAllStorage(sessionStorage);
    sendMessageToExtension({
      from: "content",
      code: "onSendData",
      data: {
        key: "send-storage",
        opt: {
          targetUrl: opt.from,
          soureurl: new URL(window.location.href).host,
          localStorage: _localStorage,
          sessionStorage: _sessionStorage
        }
      }
    });
  }
  if (opt.key === "get-storage") {
    const { setStore } = useStoragePortalStore();
    setStore(
      {
        sessionStorage: opt.data.opt.sessionStorage,
        localStorage: opt.data.opt.localStorage
      },
      true
    );
  }
  if (opt.key === "get-cookies") {
    const { setStore } = useStoragePortalStore();
    const cookies = /* @__PURE__ */ new Map();
    opt.data.cookies.forEach((c) => {
      cookies.set(c.name, {
        key: c.name,
        val: c.value
      });
    });
    const rst = [];
    cookies.forEach((c) => {
      if (c.key)
        rst.push(c);
    });
    setStore({ cookie: rst }, true);
  }
  if (opt.key === "get-tabs") {
    const options = [];
    opt.data.openWebSites.forEach((o) => {
      const isExclude = options.some((item) => item.url === new URL(o.url).host) || new URL(o.url).host === new URL(window.location.href).host || o.url.startsWith("chrome://");
      if (!isExclude) {
        options.push({
          url: new URL(o.url).host,
          title: o.title
        });
      }
    });
    const { setTabs } = useStoragePortalStore();
    setTabs(options);
  }
};
const _hoisted_1$2 = { class: "click-count" };
const _hoisted_2$2 = { class: "click-header" };
const _hoisted_3$2 = { class: "count-value" };
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "click-count",
  setup(__props) {
    const { count, add } = useClickCountStore();
    const data = ref([]);
    watchEffect(() => {
      if (count.value === 0) {
        data.value = [];
      }
    });
    const handleClick = async (e) => {
      await add(1);
      const x = e.clientX;
      const y = e.clientY;
      const id = Date.now();
      const time = Date.now();
      const color = `hsl(${Math.random() * 360}, 100%, 50%)`;
      const val = count.value;
      data.value.push({ x, y, id, time, color, val });
    };
    document.addEventListener("click", handleClick, {
      capture: true
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        createBaseVNode("div", _hoisted_2$2, [
          createBaseVNode("span", null, [
            createTextVNode(" Count: "),
            createBaseVNode("span", _hoisted_3$2, toDisplayString(unref(count)), 1)
          ])
        ]),
        (openBlock(true), createElementBlock(Fragment, null, renderList(data.value, (item) => {
          return openBlock(), createElementBlock("div", {
            key: item.id,
            class: "click-item",
            style: normalizeStyle({
              left: `${item.x}px`,
              top: `${item.y}px`,
              background: item.color
            })
          }, toDisplayString(item.val), 5);
        }), 128))
      ]);
    };
  }
});
const clickCount_vue_vue_type_style_index_0_scoped_4303e884_shadow_clickCount_lang = "";
const Count = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-4303e884"]]);
const APP_SELCTOR$1 = "click-count";
const injectView = () => {
  const isExist = document.querySelector(`#${APP_SELCTOR$1}`);
  if (isExist)
    return true;
  createApp({
    app: { component: Count },
    config: { appSelector: "click-count", predStyle: "assets/click-count.css" }
  });
};
const removeView = () => {
  var _a, _b;
  const app = (_a = document.body) == null ? void 0 : _a.querySelector(`#${APP_SELCTOR$1}`);
  app && ((_b = app.parentNode) == null ? void 0 : _b.removeChild(app));
};
const initClickCount = async () => {
  const { status } = useClickCountStore();
  if (status.value === 1) {
    const timer = setTimeout(() => {
      const isExist = injectView();
      if (isExist)
        clearTimeout(timer);
    }, 100);
  } else {
    removeView();
  }
};
const clickCount = ({ key }) => {
  console.log("clickCount", key);
  if (key === "init-click")
    initClickCount();
  if (key === "stop-click")
    removeView();
};
const contentFunc = {
  WebNotice: webNotice,
  DevAccount: devAccount,
  LinkGo: linkGo,
  StoragePortal: storagePortal,
  ClickCount: clickCount
};
const coreRelaod = (option) => {
  const { reload } = option;
  if (Array.isArray(reload)) {
    if (reload.some((url) => window.location.href.includes(url))) {
      window.location.reload();
    }
  } else if (typeof reload === "boolean" && reload) {
    window.location.reload();
  }
};
const contentCore = (options) => {
  if (!options)
    return;
  const { key, data } = options;
  if (key === "doc-reload")
    coreRelaod(data);
};
const injectScript = "/assets/index.ts-cb9f4317.js";
const _hoisted_1$1 = { class: "dev-tester-dialog-header" };
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("span", null, null, -1);
const _hoisted_3$1 = {
  key: 0,
  class: "dev-tester-dialog-title"
};
const _hoisted_4$1 = ["src"];
const _hoisted_5$1 = /* @__PURE__ */ createBaseVNode("path", {
  fill: "currentColor",
  d: "M764.288 214.592 512 466.88 259.712 214.592a31.936 31.936 0 0 0-45.12 45.12L466.752 512 214.528 764.224a31.936 31.936 0 1 0 45.12 45.184L512 557.184l252.288 252.288a31.936 31.936 0 0 0 45.12-45.12L557.12 512.064l252.288-252.352a31.936 31.936 0 1 0-45.12-45.184z"
}, null, -1);
const _hoisted_6$1 = [
  _hoisted_5$1
];
const _hoisted_7 = { class: "dev-tester-dialog-body" };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Dialog",
  props: {
    modelValue: {
      type: Boolean,
      default: false
    },
    direction: {
      type: String,
      default: "left"
    },
    tool: {
      type: Object,
      default: () => ({})
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { expose: __expose, emit }) {
    const props = __props;
    const stateVisable = ref(false);
    watch(
      () => props.modelValue,
      (val) => {
        stateVisable.value = val;
      }
    );
    const show = () => {
      stateVisable.value = true;
    };
    const close = () => {
      stateVisable.value = false;
      emit("update:modelValue", false);
    };
    const { isLogin } = useAuth();
    __expose({
      show
    });
    return (_ctx, _cache) => {
      return stateVisable.value ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: normalizeClass(`dev-tester-dialog dev-tester-${__props.direction}`),
        style: normalizeStyle({ width: __props.tool.width || "400px" })
      }, [
        createBaseVNode("div", _hoisted_1$1, [
          _hoisted_2$1,
          unref(isLogin) || !__props.tool.isLogin ? (openBlock(), createElementBlock("span", _hoisted_3$1, [
            createBaseVNode("img", {
              class: "tool-logo",
              src: __props.tool.logo
            }, null, 8, _hoisted_4$1),
            createBaseVNode("span", null, toDisplayString(__props.tool.title), 1)
          ])) : createCommentVNode("", true),
          (openBlock(), createElementBlock("svg", {
            class: "dev-tester-dialog-close",
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 1024 1024",
            onClick: close
          }, _hoisted_6$1))
        ]),
        createBaseVNode("div", _hoisted_7, [
          !unref(isLogin) && __props.tool.isLogin ? (openBlock(), createBlock(_sfc_main$3, {
            key: 0,
            "is-inject": true
          })) : !__props.tool.name ? (openBlock(), createBlock(unref(Empty), { key: 1 })) : (openBlock(), createBlock(resolveDynamicComponent(`Inject${__props.tool.name}`), { key: 2 }))
        ])
      ], 6)) : createCommentVNode("", true);
    };
  }
});
function tryOnScopeDispose(fn) {
  if (getCurrentScope()) {
    onScopeDispose(fn);
    return true;
  }
  return false;
}
function toValue(r) {
  return typeof r === "function" ? r() : unref(r);
}
const isClient = typeof window !== "undefined" && typeof document !== "undefined";
typeof WorkerGlobalScope !== "undefined" && globalThis instanceof WorkerGlobalScope;
const toString = Object.prototype.toString;
const isObject = (val) => toString.call(val) === "[object Object]";
const noop = () => {
};
function toRefs(objectRef, options = {}) {
  if (!isRef(objectRef))
    return toRefs$1(objectRef);
  const result = Array.isArray(objectRef.value) ? Array.from({ length: objectRef.value.length }) : {};
  for (const key in objectRef.value) {
    result[key] = customRef(() => ({
      get() {
        return objectRef.value[key];
      },
      set(v) {
        var _a;
        const replaceRef = (_a = toValue(options.replaceRef)) != null ? _a : true;
        if (replaceRef) {
          if (Array.isArray(objectRef.value)) {
            const copy = [...objectRef.value];
            copy[key] = v;
            objectRef.value = copy;
          } else {
            const newObject = { ...objectRef.value, [key]: v };
            Object.setPrototypeOf(newObject, Object.getPrototypeOf(objectRef.value));
            objectRef.value = newObject;
          }
        } else {
          objectRef.value[key] = v;
        }
      }
    }));
  }
  return result;
}
function unrefElement(elRef) {
  var _a;
  const plain = toValue(elRef);
  return (_a = plain == null ? void 0 : plain.$el) != null ? _a : plain;
}
const defaultWindow = isClient ? window : void 0;
function useEventListener(...args) {
  let target;
  let events;
  let listeners;
  let options;
  if (typeof args[0] === "string" || Array.isArray(args[0])) {
    [events, listeners, options] = args;
    target = defaultWindow;
  } else {
    [target, events, listeners, options] = args;
  }
  if (!target)
    return noop;
  if (!Array.isArray(events))
    events = [events];
  if (!Array.isArray(listeners))
    listeners = [listeners];
  const cleanups = [];
  const cleanup = () => {
    cleanups.forEach((fn) => fn());
    cleanups.length = 0;
  };
  const register = (el, event, listener, options2) => {
    el.addEventListener(event, listener, options2);
    return () => el.removeEventListener(event, listener, options2);
  };
  const stopWatch = watch(
    () => [unrefElement(target), toValue(options)],
    ([el, options2]) => {
      cleanup();
      if (!el)
        return;
      const optionsClone = isObject(options2) ? { ...options2 } : options2;
      cleanups.push(
        ...events.flatMap((event) => {
          return listeners.map((listener) => register(el, event, listener, optionsClone));
        })
      );
    },
    { immediate: true, flush: "post" }
  );
  const stop = () => {
    stopWatch();
    cleanup();
  };
  tryOnScopeDispose(stop);
  return stop;
}
function useDraggable(target, options = {}) {
  var _a, _b;
  const {
    pointerTypes,
    preventDefault,
    stopPropagation,
    exact,
    onMove,
    onEnd,
    onStart,
    initialValue,
    axis = "both",
    draggingElement = defaultWindow,
    containerElement,
    handle: draggingHandle = target
  } = options;
  const position = ref(
    (_a = toValue(initialValue)) != null ? _a : { x: 0, y: 0 }
  );
  const pressedDelta = ref();
  const filterEvent = (e) => {
    if (pointerTypes)
      return pointerTypes.includes(e.pointerType);
    return true;
  };
  const handleEvent = (e) => {
    if (toValue(preventDefault))
      e.preventDefault();
    if (toValue(stopPropagation))
      e.stopPropagation();
  };
  const start = (e) => {
    var _a2;
    if (toValue(options.disabled) || !filterEvent(e))
      return;
    if (toValue(exact) && e.target !== toValue(target))
      return;
    const container = toValue(containerElement);
    const containerRect = (_a2 = container == null ? void 0 : container.getBoundingClientRect) == null ? void 0 : _a2.call(container);
    const targetRect = toValue(target).getBoundingClientRect();
    const pos = {
      x: e.clientX - (container ? targetRect.left - containerRect.left + container.scrollLeft : targetRect.left),
      y: e.clientY - (container ? targetRect.top - containerRect.top + container.scrollTop : targetRect.top)
    };
    if ((onStart == null ? void 0 : onStart(pos, e)) === false)
      return;
    pressedDelta.value = pos;
    handleEvent(e);
  };
  const move = (e) => {
    if (toValue(options.disabled) || !filterEvent(e))
      return;
    if (!pressedDelta.value)
      return;
    const container = toValue(containerElement);
    const targetRect = toValue(target).getBoundingClientRect();
    let { x, y } = position.value;
    if (axis === "x" || axis === "both") {
      x = e.clientX - pressedDelta.value.x;
      if (container)
        x = Math.min(Math.max(0, x), container.scrollWidth - targetRect.width);
    }
    if (axis === "y" || axis === "both") {
      y = e.clientY - pressedDelta.value.y;
      if (container)
        y = Math.min(Math.max(0, y), container.scrollHeight - targetRect.height);
    }
    position.value = {
      x,
      y
    };
    onMove == null ? void 0 : onMove(position.value, e);
    handleEvent(e);
  };
  const end = (e) => {
    if (toValue(options.disabled) || !filterEvent(e))
      return;
    if (!pressedDelta.value)
      return;
    pressedDelta.value = void 0;
    onEnd == null ? void 0 : onEnd(position.value, e);
    handleEvent(e);
  };
  if (isClient) {
    const config = { capture: (_b = options.capture) != null ? _b : true };
    useEventListener(draggingHandle, "pointerdown", start, config);
    useEventListener(draggingElement, "pointermove", move, config);
    useEventListener(draggingElement, "pointerup", end, config);
  }
  return {
    ...toRefs(position),
    position,
    isDragging: computed(() => !!pressedDelta.value),
    style: computed(
      () => `left:${position.value.x}px;top:${position.value.y}px;`
    )
  };
}
const App = "";
const logo = "/assets/logo16.png";
const _hoisted_1 = ["src"];
const _hoisted_2 = { class: "dev-tester-content" };
const _hoisted_3 = { class: "dev-tester-footer" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("span", { class: "line" }, null, -1);
const _hoisted_5 = ["onClick"];
const _hoisted_6 = ["src"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "App",
  setup(__props) {
    const { syncStore } = useApp();
    const { theme, direction, posY, setTheme, setPosY } = useTheme();
    const kitRef = ref();
    const { y, isDragging } = useDraggable(kitRef, {
      axis: "y",
      onEnd: ({ y: y2 }) => {
        setPosY(y2);
      }
    });
    watch(
      () => posY.value,
      (val) => {
        y.value = val;
      },
      {
        immediate: true
      }
    );
    const { contentApps, contentInnerApps } = useApp();
    const logoUrl = chrome.runtime.getURL(logo);
    const lastPosY = ref();
    const catchPos = () => {
      lastPosY.value = y.value;
    };
    const isActive = ref(false);
    const isVisable = ref(false);
    let openTimer;
    let leaveTimer;
    const clickToolBar = (payload) => {
      if (openTimer)
        clearTimeout(openTimer);
      if (payload.button !== 0)
        return;
      setTimeout(() => {
        const gap = Math.abs(lastPosY.value - y.value) < 10;
        if (gap)
          isActive.value = !isActive.value;
      }, 0);
    };
    const hoverToolBar = () => {
      clearTimeout(openTimer);
      clearTimeout(leaveTimer);
      if (isDragging.value)
        return;
      openTimer = setTimeout(() => {
        isActive.value = true;
        clearTimeout(openTimer);
      }, 1e3);
    };
    watchEffect(() => {
      if (isActive.value) {
        syncStore();
      }
    });
    const leaveToolBar = (isBar = false) => {
      if (!isBar && isActive.value || isDragging.value)
        return;
      clearTimeout(openTimer);
      leaveTimer = setTimeout(() => {
        isActive.value = false;
        clearTimeout(leaveTimer);
      }, 800);
    };
    const current = ref();
    const openPage = (code, url, extra = {}) => {
      injectPostMessage({
        from: "app_inject",
        code,
        data: {
          openUrl: url,
          extra
        }
      });
    };
    const openLogin = () => {
      openPage("onOpenWindow", "login.html", {
        focused: true,
        width: 500,
        height: 680,
        left: 400,
        top: 100,
        type: "panel"
      });
    };
    const appClick = async (tool) => {
      var _a;
      if (tool.linkUrl) {
        openPage("onOpenChromeUrl", "setting.html");
        return;
      }
      if (((_a = current.value) == null ? void 0 : _a.name) && tool.name !== current.value.name) {
        isVisable.value = true;
      } else
        isVisable.value = !isVisable.value;
      if (isVisable.value)
        current.value = tool;
      else
        current.value = null;
    };
    watch(
      () => isDragging.value,
      () => {
        clearTimeout(openTimer);
        clearTimeout(leaveTimer);
      }
    );
    provide("appContent", {
      setDialog: (val) => {
        isVisable.value = val;
      },
      openPage,
      openLogin
    });
    watchEffect(() => {
      if (!isVisable.value) {
        current.value = void 0;
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["dev-tester-app", [unref(theme)]]),
        style: { "display": "none" }
      }, [
        createBaseVNode("div", {
          ref_key: "kitRef",
          ref: kitRef,
          class: normalizeClass(["kit-tool-warper", [`${unref(direction)}-kit`]]),
          style: normalizeStyle({ top: unref(y) ? `${unref(y)}px` : `38%` })
        }, [
          createBaseVNode("div", {
            class: normalizeClass(["kit-tool", [{ "tool-active": unref(isDragging) }]]),
            onMouseenter: hoverToolBar,
            onMouseleave: _cache[0] || (_cache[0] = () => leaveToolBar()),
            onMousedown: catchPos,
            onMouseup: clickToolBar
          }, [
            createBaseVNode("img", {
              draggable: "false",
              class: "app-logo",
              src: unref(logoUrl),
              alt: "logo"
            }, null, 8, _hoisted_1)
          ], 34)
        ], 6),
        createBaseVNode("div", {
          class: normalizeClass(["dev-tester-kit", [`${unref(direction)}-mode`]]),
          onMouseenter: hoverToolBar,
          onMouseleave: _cache[1] || (_cache[1] = () => leaveToolBar(true))
        }, [
          createBaseVNode("div", {
            class: normalizeClass(["dev-tester-tool-bar", {
              "dev-tester-active": isActive.value || isVisable.value
            }])
          }, [
            createBaseVNode("div", _hoisted_2, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(contentApps), (app) => {
                var _a;
                return openBlock(), createBlock(_sfc_main$4, {
                  key: app.name,
                  title: app.title,
                  logo: app.logo,
                  active: app.name === ((_a = current.value) == null ? void 0 : _a.name),
                  onClick: ($event) => appClick(app)
                }, null, 8, ["title", "logo", "active", "onClick"]);
              }), 128))
            ]),
            createBaseVNode("div", _hoisted_3, [
              _hoisted_4,
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(contentInnerApps), (innerApp) => {
                return openBlock(), createElementBlock("div", {
                  key: innerApp.name,
                  class: "footer-operate btn m-t-1",
                  onClick: ($event) => appClick(innerApp)
                }, [
                  createBaseVNode("img", {
                    src: innerApp.logo
                  }, null, 8, _hoisted_6)
                ], 8, _hoisted_5);
              }), 128))
            ])
          ], 2)
        ], 34),
        createVNode(_sfc_main$1, {
          modelValue: isVisable.value,
          "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isVisable.value = $event),
          direction: unref(direction),
          tool: current.value
        }, null, 8, ["modelValue", "direction", "tool"])
      ], 2);
    };
  }
});
const APP_SELCTOR = "dev-tester-extension";
const initInject = () => {
  var _a;
  const isExist = document.querySelector(`#${APP_SELCTOR}`);
  if (isExist)
    return true;
  const container = document.createElement("div");
  container.id = `${APP_SELCTOR}`;
  setTimeout(() => {
    var _a2;
    return (_a2 = document.body) == null ? void 0 : _a2.appendChild(container);
  }, 0);
  const root = document.createElement("div");
  root.id = `${APP_SELCTOR}-root`;
  const shadowDOM = (_a = container.attachShadow) == null ? void 0 : _a.call(container, { mode: "open" });
  {
    const styleEl = document.createElement("link");
    styleEl.setAttribute("rel", "stylesheet");
    styleEl.setAttribute(
      "href",
      chrome.runtime.getURL("/assets/shadow-styles.css")
    );
    shadowDOM.appendChild(styleEl);
  }
  shadowDOM.appendChild(root);
  const app = createApp$1(_sfc_main);
  contentInstall(app);
  app.mount(root);
};
const removeInject = () => {
  var _a, _b;
  const app = (_a = document.body) == null ? void 0 : _a.querySelector(`#${APP_SELCTOR}`);
  app && ((_b = app.parentNode) == null ? void 0 : _b.removeChild(app));
};
const { bubble } = useTheme();
const initContent = () => {
  initInject();
  const timer = setTimeout(() => {
    const isExist = initInject();
    if (isExist)
      clearTimeout(timer);
  }, 100);
};
if (bubble.value) {
  initContent();
} else {
  removeInject();
}
watch(
  () => bubble.value,
  (value) => {
    if (value) {
      initContent();
    } else {
      removeInject();
    }
  }
);
injectCustomScript(injectScript);
const contentInit = () => {
  sendMessageToExtension({
    from: "content",
    code: "onContentInit",
    data: {
      url: window.location.href
    }
  });
};
contentInit();
document.addEventListener("DOMContentLoaded", () => {
  sendMessageToExtension({
    from: "content",
    code: "onDocDOMContentLoaded",
    data: {
      url: window.location.href
    }
  });
});
window.addEventListener("load", () => {
  sendMessageToExtension({
    from: "content",
    code: "onDocLoad",
    data: { url: window.location.href }
  });
});
window.addEventListener("pageshow", () => {
  sendMessageToExtension({
    from: "content",
    code: "onPageshow",
    data: { url: window.location.href }
  });
});
window.addEventListener("popstate", (event) => {
  sendMessageToExtension({
    from: "content",
    code: "onUrlChange",
    data: { url: window.location.href, event }
  });
});
window.addEventListener("hashchange", (event) => {
  sendMessageToExtension({
    from: "content",
    code: "onUrlChange",
    data: { url: window.location.href, event }
  });
});
window.addEventListener("message", async (info) => {
  const { data } = info;
  if (data.from !== "app_inject")
    return;
  if (data.code === "onDocVisibilitychange") {
    if (data.data && data.data.visible) {
      initInject();
    }
  }
  sendMessageToExtension({
    ...data,
    from: "content"
  });
});
chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
  const { code, data } = request;
  if (code === "CoreApp") {
    contentCore(data);
  } else {
    const funcCall = contentFunc[code];
    if (funcCall) {
      funcCall(data);
    }
  }
  sendResponse();
  return false;
});
