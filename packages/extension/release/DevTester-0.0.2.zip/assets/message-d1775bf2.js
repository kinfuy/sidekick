var Message;
((Message2) => {
  ((Form2) => {
    Form2.INJECT_MESSAGE = "INJECT_MESSAGE";
    Form2.CONTENT_MESSAGE = "CONTENT_MESSAGE";
    Form2.POPUP_MESSAGE = "POPUP_MESSAGE";
    Form2.SERVERWORKER_MESSAGE = "SERVERWORKER_MESSAGE";
  })(Message2.Form || (Message2.Form = {}));
  ((Target2) => {
    Target2.INJECT = "INJECT";
    Target2.CONTENT = "CONTENT";
    Target2.POPUP = "POPUP";
    Target2.SERVERWORKER = "SERVERWORKER";
  })(Message2.Target || (Message2.Target = {}));
})(Message || (Message = {}));
export {
  Message as M
};
