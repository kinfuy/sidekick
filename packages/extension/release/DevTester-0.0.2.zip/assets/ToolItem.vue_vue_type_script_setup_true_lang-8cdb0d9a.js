import { d as defineComponent, o as openBlock, c as createElementBlock, a as createBaseVNode, n as normalizeClass } from "./runtime-core.esm-bundler-1bf05d91.js";
const _hoisted_1 = ["src", "title"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ToolItem",
  props: {
    name: {
      type: String
    },
    title: {
      type: String
    },
    logo: {
      type: String
    },
    active: {
      type: Boolean
    }
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["dev-tester-tool btn", { "tool-active": __props.active }])
      }, [
        createBaseVNode("img", {
          class: "dev-tester-tool-logo",
          src: __props.logo,
          title: __props.title
        }, null, 8, _hoisted_1)
      ], 2);
    };
  }
});
export {
  _sfc_main as _
};
