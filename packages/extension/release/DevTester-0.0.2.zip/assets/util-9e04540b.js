const loadFile = (fileName, content) => {
  const aLink = document.createElement("a");
  const blob = new Blob([content], {
    type: "text/plain"
  });
  aLink.download = fileName;
  aLink.href = URL.createObjectURL(blob);
  aLink.click();
  URL.revokeObjectURL(blob.toString());
};
const uuid = () => {
  let d = (/* @__PURE__ */ new Date()).getTime();
  const uuid2 = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (d + Math.random() * 16) % 16 | 0;
    d = Math.floor(d / 16);
    return (c === "x" ? r : r & 7 | 8).toString(16);
  });
  return uuid2;
};
const injectPostMessage = (data) => {
  window.postMessage(data, "*");
};
export {
  injectPostMessage as i,
  loadFile as l,
  uuid as u
};
