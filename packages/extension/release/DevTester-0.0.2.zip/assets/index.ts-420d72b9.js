var _a, _b;
import { N as ref, W as storage, C as toRaw, X as useAuth, Y as createtab, Z as getChromeUrl, b as createWindow, R as useApp, _ as apps, $ as chromeAddListenerMessage } from "./useAuth-a26fa5df.js";
const STORE_KEY = "alarmManager";
const store = ref({
  enabled: false,
  alarms: []
});
const useAlarmManger = () => {
  const { get, set } = storage;
  const save = () => {
    set(STORE_KEY, JSON.stringify(toRaw(store.value)));
  };
  const sync = async () => {
    let _store = {
      alarms: [],
      enabled: false
    };
    const alarm = await get(STORE_KEY);
    if (alarm && JSON.stringify(alarm) !== "{}") {
      _store = alarm;
    }
    store.value = _store;
    if (store.value.enabled) {
      store.value.alarms.forEach(async (a) => {
        const alarm2 = await chrome.alarms.get(a.name);
        if (!alarm2) {
          await chrome.alarms.create(a.name, a.alarmInfo);
          store.value.enabled = true;
          save();
        }
      });
    }
  };
  const add2 = (name, alarmInfo) => {
    store.value.alarms.push({ name, alarmInfo });
    save();
    return chrome.alarms.create(name, alarmInfo);
  };
  const find = () => {
  };
  const deleteAlarm = () => {
  };
  const update = () => {
  };
  sync();
  return {
    store,
    add: add2,
    find,
    deleteAlarm,
    update
  };
};
const PreCoreApp = () => {
  return {
    name: "pre-core-app",
    onAlarms: (opt) => {
      if (opt.name === "refresh-token") {
        const { getRefreshToken } = useAuth();
        getRefreshToken();
      }
    }
  };
};
const SuffixCoreApp = () => {
  return {
    name: "suffix-core-app",
    onOpenChromeUrl: ({ openUrl, extra }) => {
      createtab(getChromeUrl(openUrl), extra);
    },
    onOpenWindow: ({ openUrl, extra }) => {
      createWindow(getChromeUrl(openUrl), extra);
    }
  };
};
const getApplicationHooks = async (name, isActived, limitApp) => {
  const applicationHook = [];
  const { isAppActive } = useApp();
  apps.filter((a) => limitApp ? limitApp.includes(a.name) : true).forEach((app) => {
    const active = isActived ? isAppActive(app.name) : true;
    if (app.hooks[name] && active) {
      applicationHook.push(app.hooks[name]);
    }
  });
  return applicationHook;
};
const runCoreHook = async (name, app, options) => {
  const core = app();
  const coreHooks = core[name];
  if (coreHooks) {
    await coreHooks(options);
  }
};
const triggerApplicationHooks = async (name, options, limitApp) => {
  await runCoreHook(name, PreCoreApp, options);
  const actived = name !== "onActiveChange";
  const hooks = await getApplicationHooks(name, actived, limitApp);
  for (const hook of hooks) {
    await hook(options);
  }
  await runCoreHook(name, SuffixCoreApp, options);
};
chrome.runtime.onInstalled.addListener(() => {
  triggerApplicationHooks("onInstalled");
});
triggerApplicationHooks("onInit");
chromeAddListenerMessage(async (message) => {
  var _a2, _b2;
  let limitApp;
  if (message.code === "onActiveChange" && ((_a2 = message.data) == null ? void 0 : _a2.name)) {
    limitApp = [(_b2 = message.data) == null ? void 0 : _b2.name];
  }
  triggerApplicationHooks(message.code, message.data, limitApp);
});
(_a = chrome.alarms) == null ? void 0 : _a.onAlarm.addListener((opt) => {
  triggerApplicationHooks("onAlarms", opt);
});
(_b = chrome.contextMenus) == null ? void 0 : _b.onClicked.addListener((e, tab) => {
  triggerApplicationHooks("onContextMenusClick", { e, tab });
});
chrome.tabs.onUpdated.addListener((...opt) => {
  triggerApplicationHooks("onTabUpdate", opt);
});
chrome.tabs.onCreated.addListener((...opt) => {
  triggerApplicationHooks("onTabCreate", opt);
});
chrome.tabs.onRemoved.addListener((...opt) => {
  triggerApplicationHooks("onTabRemove", opt);
});
chrome.tabs.onMoved.addListener((...opt) => {
  triggerApplicationHooks("onTabMove", opt);
});
chrome.tabs.onReplaced.addListener((...opt) => {
  triggerApplicationHooks("onTabReplaced", opt);
});
const { add } = useAlarmManger();
add("refresh-token", { periodInMinutes: 60 * 24 });
