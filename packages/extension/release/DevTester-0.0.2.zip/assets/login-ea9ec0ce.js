import "./modulepreload-polyfill-7faf532e.js";
import { u as useTheme, S as Sinput, c as createApp } from "./useTheme-20657fa1.js";
import { a0 as commonjsGlobal, a1 as getDefaultExportFromCjs, d as defineComponent, N as ref, X as useAuth, T as computed, O as watch, o as openBlock, c as createElementBlock, a as createBaseVNode, u as unref, a2 as createBlock, a3 as createCommentVNode, a4 as toDisplayString, H as createVNode, n as normalizeClass, a5 as sendCodeApi, a6 as loginApi, a7 as clearActiveTab, a8 as registerApi, a9 as verifyEmailApi } from "./useAuth-a26fa5df.js";
import { l as logo } from "./logo-219d4073.js";
var md5$1 = { exports: {} };
(function(module) {
  (function($) {
    function safeAdd(x, y) {
      var lsw = (x & 65535) + (y & 65535);
      var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
      return msw << 16 | lsw & 65535;
    }
    function bitRotateLeft(num, cnt) {
      return num << cnt | num >>> 32 - cnt;
    }
    function md5cmn(q, a, b, x, s, t) {
      return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
    }
    function md5ff(a, b, c, d, x, s, t) {
      return md5cmn(b & c | ~b & d, a, b, x, s, t);
    }
    function md5gg(a, b, c, d, x, s, t) {
      return md5cmn(b & d | c & ~d, a, b, x, s, t);
    }
    function md5hh(a, b, c, d, x, s, t) {
      return md5cmn(b ^ c ^ d, a, b, x, s, t);
    }
    function md5ii(a, b, c, d, x, s, t) {
      return md5cmn(c ^ (b | ~d), a, b, x, s, t);
    }
    function binlMD5(x, len) {
      x[len >> 5] |= 128 << len % 32;
      x[(len + 64 >>> 9 << 4) + 14] = len;
      var i;
      var olda;
      var oldb;
      var oldc;
      var oldd;
      var a = 1732584193;
      var b = -271733879;
      var c = -1732584194;
      var d = 271733878;
      for (i = 0; i < x.length; i += 16) {
        olda = a;
        oldb = b;
        oldc = c;
        oldd = d;
        a = md5ff(a, b, c, d, x[i], 7, -680876936);
        d = md5ff(d, a, b, c, x[i + 1], 12, -389564586);
        c = md5ff(c, d, a, b, x[i + 2], 17, 606105819);
        b = md5ff(b, c, d, a, x[i + 3], 22, -1044525330);
        a = md5ff(a, b, c, d, x[i + 4], 7, -176418897);
        d = md5ff(d, a, b, c, x[i + 5], 12, 1200080426);
        c = md5ff(c, d, a, b, x[i + 6], 17, -1473231341);
        b = md5ff(b, c, d, a, x[i + 7], 22, -45705983);
        a = md5ff(a, b, c, d, x[i + 8], 7, 1770035416);
        d = md5ff(d, a, b, c, x[i + 9], 12, -1958414417);
        c = md5ff(c, d, a, b, x[i + 10], 17, -42063);
        b = md5ff(b, c, d, a, x[i + 11], 22, -1990404162);
        a = md5ff(a, b, c, d, x[i + 12], 7, 1804603682);
        d = md5ff(d, a, b, c, x[i + 13], 12, -40341101);
        c = md5ff(c, d, a, b, x[i + 14], 17, -1502002290);
        b = md5ff(b, c, d, a, x[i + 15], 22, 1236535329);
        a = md5gg(a, b, c, d, x[i + 1], 5, -165796510);
        d = md5gg(d, a, b, c, x[i + 6], 9, -1069501632);
        c = md5gg(c, d, a, b, x[i + 11], 14, 643717713);
        b = md5gg(b, c, d, a, x[i], 20, -373897302);
        a = md5gg(a, b, c, d, x[i + 5], 5, -701558691);
        d = md5gg(d, a, b, c, x[i + 10], 9, 38016083);
        c = md5gg(c, d, a, b, x[i + 15], 14, -660478335);
        b = md5gg(b, c, d, a, x[i + 4], 20, -405537848);
        a = md5gg(a, b, c, d, x[i + 9], 5, 568446438);
        d = md5gg(d, a, b, c, x[i + 14], 9, -1019803690);
        c = md5gg(c, d, a, b, x[i + 3], 14, -187363961);
        b = md5gg(b, c, d, a, x[i + 8], 20, 1163531501);
        a = md5gg(a, b, c, d, x[i + 13], 5, -1444681467);
        d = md5gg(d, a, b, c, x[i + 2], 9, -51403784);
        c = md5gg(c, d, a, b, x[i + 7], 14, 1735328473);
        b = md5gg(b, c, d, a, x[i + 12], 20, -1926607734);
        a = md5hh(a, b, c, d, x[i + 5], 4, -378558);
        d = md5hh(d, a, b, c, x[i + 8], 11, -2022574463);
        c = md5hh(c, d, a, b, x[i + 11], 16, 1839030562);
        b = md5hh(b, c, d, a, x[i + 14], 23, -35309556);
        a = md5hh(a, b, c, d, x[i + 1], 4, -1530992060);
        d = md5hh(d, a, b, c, x[i + 4], 11, 1272893353);
        c = md5hh(c, d, a, b, x[i + 7], 16, -155497632);
        b = md5hh(b, c, d, a, x[i + 10], 23, -1094730640);
        a = md5hh(a, b, c, d, x[i + 13], 4, 681279174);
        d = md5hh(d, a, b, c, x[i], 11, -358537222);
        c = md5hh(c, d, a, b, x[i + 3], 16, -722521979);
        b = md5hh(b, c, d, a, x[i + 6], 23, 76029189);
        a = md5hh(a, b, c, d, x[i + 9], 4, -640364487);
        d = md5hh(d, a, b, c, x[i + 12], 11, -421815835);
        c = md5hh(c, d, a, b, x[i + 15], 16, 530742520);
        b = md5hh(b, c, d, a, x[i + 2], 23, -995338651);
        a = md5ii(a, b, c, d, x[i], 6, -198630844);
        d = md5ii(d, a, b, c, x[i + 7], 10, 1126891415);
        c = md5ii(c, d, a, b, x[i + 14], 15, -1416354905);
        b = md5ii(b, c, d, a, x[i + 5], 21, -57434055);
        a = md5ii(a, b, c, d, x[i + 12], 6, 1700485571);
        d = md5ii(d, a, b, c, x[i + 3], 10, -1894986606);
        c = md5ii(c, d, a, b, x[i + 10], 15, -1051523);
        b = md5ii(b, c, d, a, x[i + 1], 21, -2054922799);
        a = md5ii(a, b, c, d, x[i + 8], 6, 1873313359);
        d = md5ii(d, a, b, c, x[i + 15], 10, -30611744);
        c = md5ii(c, d, a, b, x[i + 6], 15, -1560198380);
        b = md5ii(b, c, d, a, x[i + 13], 21, 1309151649);
        a = md5ii(a, b, c, d, x[i + 4], 6, -145523070);
        d = md5ii(d, a, b, c, x[i + 11], 10, -1120210379);
        c = md5ii(c, d, a, b, x[i + 2], 15, 718787259);
        b = md5ii(b, c, d, a, x[i + 9], 21, -343485551);
        a = safeAdd(a, olda);
        b = safeAdd(b, oldb);
        c = safeAdd(c, oldc);
        d = safeAdd(d, oldd);
      }
      return [a, b, c, d];
    }
    function binl2rstr(input) {
      var i;
      var output = "";
      var length32 = input.length * 32;
      for (i = 0; i < length32; i += 8) {
        output += String.fromCharCode(input[i >> 5] >>> i % 32 & 255);
      }
      return output;
    }
    function rstr2binl(input) {
      var i;
      var output = [];
      output[(input.length >> 2) - 1] = void 0;
      for (i = 0; i < output.length; i += 1) {
        output[i] = 0;
      }
      var length8 = input.length * 8;
      for (i = 0; i < length8; i += 8) {
        output[i >> 5] |= (input.charCodeAt(i / 8) & 255) << i % 32;
      }
      return output;
    }
    function rstrMD5(s) {
      return binl2rstr(binlMD5(rstr2binl(s), s.length * 8));
    }
    function rstrHMACMD5(key, data) {
      var i;
      var bkey = rstr2binl(key);
      var ipad = [];
      var opad = [];
      var hash;
      ipad[15] = opad[15] = void 0;
      if (bkey.length > 16) {
        bkey = binlMD5(bkey, key.length * 8);
      }
      for (i = 0; i < 16; i += 1) {
        ipad[i] = bkey[i] ^ 909522486;
        opad[i] = bkey[i] ^ 1549556828;
      }
      hash = binlMD5(ipad.concat(rstr2binl(data)), 512 + data.length * 8);
      return binl2rstr(binlMD5(opad.concat(hash), 512 + 128));
    }
    function rstr2hex(input) {
      var hexTab = "0123456789abcdef";
      var output = "";
      var x;
      var i;
      for (i = 0; i < input.length; i += 1) {
        x = input.charCodeAt(i);
        output += hexTab.charAt(x >>> 4 & 15) + hexTab.charAt(x & 15);
      }
      return output;
    }
    function str2rstrUTF8(input) {
      return unescape(encodeURIComponent(input));
    }
    function rawMD5(s) {
      return rstrMD5(str2rstrUTF8(s));
    }
    function hexMD5(s) {
      return rstr2hex(rawMD5(s));
    }
    function rawHMACMD5(k, d) {
      return rstrHMACMD5(str2rstrUTF8(k), str2rstrUTF8(d));
    }
    function hexHMACMD5(k, d) {
      return rstr2hex(rawHMACMD5(k, d));
    }
    function md52(string, key, raw) {
      if (!key) {
        if (!raw) {
          return hexMD5(string);
        }
        return rawMD5(string);
      }
      if (!raw) {
        return hexHMACMD5(key, string);
      }
      return rawHMACMD5(key, string);
    }
    if (module.exports) {
      module.exports = md52;
    } else {
      $.md5 = md52;
    }
  })(commonjsGlobal);
})(md5$1);
var md5Exports = md5$1.exports;
const blueimpMd5 = /* @__PURE__ */ getDefaultExportFromCjs(md5Exports);
const md5 = (str) => {
  return blueimpMd5(str);
};
const _hoisted_1 = { class: "dev-tester-content" };
const _hoisted_2 = { class: "dev-tester-login-logo" };
const _hoisted_3 = { class: "logo-content" };
const _hoisted_4 = ["src"];
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("span", { class: "logo-title" }, "DevTester", -1);
const _hoisted_6 = { class: "login-content" };
const _hoisted_7 = { key: 1 };
const _hoisted_8 = {
  key: 2,
  class: "login-verify"
};
const _hoisted_9 = { class: "login-error" };
const _hoisted_10 = { class: "login-operate" };
const _hoisted_11 = { class: "login-oprate-footer" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "login",
  setup(__props) {
    const logoIcon = chrome.runtime.getURL(logo);
    const mode = ref("login");
    const { theme } = useTheme();
    const { setUser } = useAuth();
    const errorTips = ref("");
    const model = ref({
      email: "",
      password: "",
      repassword: "",
      verifyCode: ""
    });
    const btnText = computed(() => {
      if (mode.value === "login")
        return "登录/注册";
      if (mode.value === "register")
        return "重置密码";
      if (mode.value === "confirm")
        return "验证邮箱";
      return "";
    });
    const descText = computed(() => {
      if (mode.value === "login")
        return "忘记密码？";
      if (mode.value === "register")
        return "已有账号?";
      if (mode.value === "confirm")
        return "已有账号?";
      return "";
    });
    const checkForm = (type) => {
      if (mode.value === "login") {
        if (!model.value.email) {
          if (type === "all" || type === "email")
            errorTips.value = "请输入邮箱";
          return false;
        }
        const regEmail = /^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/;
        if (!regEmail.test(model.value.email)) {
          if (type === "all" || type === "email")
            errorTips.value = "请输入正确的邮箱";
          return false;
        }
        if (!model.value.password) {
          if (type === "all" || type === "password")
            errorTips.value = "请输入密码";
          return false;
        }
      }
      if (mode.value === "register") {
        if (!model.value.email) {
          if (type === "all" || type === "email")
            errorTips.value = "请输入邮箱";
          return false;
        }
        if (!model.value.verifyCode) {
          if (type === "all" || type === "verifyCode")
            errorTips.value = "请输入验证码";
          return false;
        }
        if (!model.value.password) {
          if (type === "all" || type === "password")
            errorTips.value = "请输入密码";
          return false;
        }
        if (!model.value.repassword) {
          if (type === "all" || type === "repassword")
            errorTips.value = "请再次输入密码";
          return false;
        }
        if (model.value.password !== model.value.repassword) {
          if (type === "all" || type === "repassword" || type === "password")
            errorTips.value = "密码不一致";
          return false;
        }
      }
      if (mode.value === "confirm") {
        if (!model.value.email) {
          if (type === "all" || type === "email")
            errorTips.value = "请输入邮箱";
          return false;
        }
        if (!model.value.verifyCode) {
          if (type === "all" || type === "verifyCode")
            errorTips.value = "请输入验证码";
        }
      }
      errorTips.value = "";
      return true;
    };
    const createQuery = () => {
      if (mode.value === "login") {
        return {
          email: model.value.email,
          password: md5(model.value.password + model.value.email)
        };
      }
      if (mode.value === "register") {
        return {
          email: model.value.email,
          password: md5(model.value.password + model.value.email),
          verifyCode: model.value.verifyCode
        };
      }
      if (mode.value === "confirm") {
        return {
          email: model.value.email,
          password: md5(model.value.password + model.value.email),
          verifyCode: model.value.verifyCode
        };
      }
      return {};
    };
    const login = async () => {
      const check = checkForm("all");
      if (!check)
        return;
      const query = createQuery();
      const user = await loginApi(query).catch(
        (err) => {
          errorTips.value = err.message || "登录失败";
        }
      );
      if (user) {
        errorTips.value = "";
        if (user.confirm) {
          mode.value = "confirm";
          return;
        }
        setUser({
          accessToken: user.accessToken,
          refreshToken: user.refreshToken,
          email: model.value.email,
          avatar: user.avatar,
          name: user.name,
          description: user.description,
          subscription: user.subscription
        });
        clearActiveTab();
      }
    };
    const register = async () => {
      const check = checkForm("all");
      if (!check)
        return;
      const query = createQuery();
      const user = await registerApi(query).catch((err) => {
        errorTips.value = err.message || "注册失败";
      });
      if (user) {
        setUser({
          accessToken: user.accessToken,
          refreshToken: user.refreshToken,
          email: model.value.email,
          avatar: user.avatar,
          name: user.name,
          description: user.description
        });
        clearActiveTab();
      }
    };
    const count = ref(60);
    const sendCode = async () => {
      const check = checkForm("all");
      if (!check)
        return;
      if (count.value < 60)
        return;
      count.value = 60;
      const timer = setInterval(() => {
        count.value--;
        if (count.value === 0) {
          count.value = 60;
          clearInterval(timer);
        }
      }, 1e3);
      await sendCodeApi({
        email: model.value.email
      }).catch((err) => {
        clearInterval(timer);
        count.value = 60;
        errorTips.value = err.message || "验证码发送失败";
      });
    };
    const verifyEmail = async () => {
      const check = checkForm("all");
      if (!check)
        return;
      const query = createQuery();
      const user = await verifyEmailApi(query).catch((err) => {
        errorTips.value = err.message || "验证失败";
      });
      if (user) {
        setUser({
          accessToken: user.accessToken,
          refreshToken: user.refreshToken,
          email: model.value.email,
          avatar: user.avatar,
          name: user.name,
          description: user.description,
          subscription: user.subscription
        });
        clearActiveTab();
      }
    };
    const btnAction = () => {
      if (mode.value === "login")
        login();
      if (mode.value === "register")
        register();
      if (mode.value === "confirm")
        verifyEmail();
    };
    watch(
      () => mode.value,
      () => {
        errorTips.value = "";
      }
    );
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["dev-tester-login", [unref(theme)]])
      }, [
        createBaseVNode("div", _hoisted_1, [
          createBaseVNode("div", _hoisted_2, [
            createBaseVNode("div", _hoisted_3, [
              createBaseVNode("img", {
                src: unref(logoIcon),
                alt: "logo"
              }, null, 8, _hoisted_4),
              _hoisted_5
            ])
          ]),
          createBaseVNode("div", _hoisted_6, [
            mode.value !== "confirm" ? (openBlock(), createBlock(unref(Sinput), {
              key: 0,
              modelValue: model.value.email,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => model.value.email = $event),
              class: "login-form-item",
              placeholder: "请输入邮箱",
              onBlur: _cache[1] || (_cache[1] = () => checkForm("email"))
            }, null, 8, ["modelValue"])) : createCommentVNode("", true),
            mode.value === "confirm" ? (openBlock(), createElementBlock("span", _hoisted_7, toDisplayString(model.value.email), 1)) : createCommentVNode("", true),
            mode.value === "register" || mode.value === "confirm" ? (openBlock(), createElementBlock("div", _hoisted_8, [
              createVNode(unref(Sinput), {
                modelValue: model.value.verifyCode,
                "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => model.value.verifyCode = $event),
                placeholder: "请输入邮箱收到的验证码",
                onBlur: _cache[3] || (_cache[3] = () => checkForm("verifyCode"))
              }, null, 8, ["modelValue"]),
              createBaseVNode("div", {
                class: "login-verify-code btn-border",
                onClick: sendCode
              }, toDisplayString(count.value === 60 ? "获取" : `${count.value}s`), 1)
            ])) : createCommentVNode("", true),
            mode.value !== "confirm" ? (openBlock(), createBlock(unref(Sinput), {
              key: 3,
              modelValue: model.value.password,
              "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => model.value.password = $event),
              class: "login-form-item",
              type: "password",
              placeholder: "请输入密码",
              onBlur: _cache[5] || (_cache[5] = () => checkForm("password"))
            }, null, 8, ["modelValue"])) : createCommentVNode("", true),
            mode.value === "register" ? (openBlock(), createBlock(unref(Sinput), {
              key: 4,
              modelValue: model.value.repassword,
              "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => model.value.repassword = $event),
              class: "login-form-item",
              type: "password",
              placeholder: "请再次输入密码",
              onBlur: _cache[7] || (_cache[7] = () => checkForm("repassword"))
            }, null, 8, ["modelValue"])) : createCommentVNode("", true)
          ]),
          createBaseVNode("div", _hoisted_9, toDisplayString(errorTips.value ?? ""), 1),
          createBaseVNode("div", _hoisted_10, [
            createBaseVNode("div", {
              class: "btn btn-border btn-block btn-primary",
              onClick: btnAction
            }, toDisplayString(btnText.value), 1),
            createBaseVNode("div", _hoisted_11, [
              createBaseVNode("div", {
                class: "btn-text",
                onClick: _cache[8] || (_cache[8] = ($event) => mode.value = mode.value === "login" ? "register" : "login")
              }, toDisplayString(descText.value), 1)
            ])
          ])
        ])
      ], 2);
    };
  }
});
const Login = "";
const app = createApp(_sfc_main);
app.mount("#login-app");
