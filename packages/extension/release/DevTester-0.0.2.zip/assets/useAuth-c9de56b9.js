var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { M as ref, A as toRaw, Q as computed } from "./runtime-core.esm-bundler-1bf05d91.js";
var commonjsGlobal = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
function getDefaultExportFromCjs(x) {
  return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
}
var dayjs_min = { exports: {} };
(function(module, exports) {
  !function(t2, e) {
    module.exports = e();
  }(commonjsGlobal, function() {
    var t2 = 1e3, e = 6e4, n = 36e5, r = "millisecond", i = "second", s = "minute", u = "hour", a = "day", o = "week", c = "month", f = "quarter", h = "year", d = "date", l = "Invalid Date", $ = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, y = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, M = { name: "en", weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), ordinal: function(t3) {
      var e2 = ["th", "st", "nd", "rd"], n2 = t3 % 100;
      return "[" + t3 + (e2[(n2 - 20) % 10] || e2[n2] || e2[0]) + "]";
    } }, m = function(t3, e2, n2) {
      var r2 = String(t3);
      return !r2 || r2.length >= e2 ? t3 : "" + Array(e2 + 1 - r2.length).join(n2) + t3;
    }, v = { s: m, z: function(t3) {
      var e2 = -t3.utcOffset(), n2 = Math.abs(e2), r2 = Math.floor(n2 / 60), i2 = n2 % 60;
      return (e2 <= 0 ? "+" : "-") + m(r2, 2, "0") + ":" + m(i2, 2, "0");
    }, m: function t3(e2, n2) {
      if (e2.date() < n2.date())
        return -t3(n2, e2);
      var r2 = 12 * (n2.year() - e2.year()) + (n2.month() - e2.month()), i2 = e2.clone().add(r2, c), s2 = n2 - i2 < 0, u2 = e2.clone().add(r2 + (s2 ? -1 : 1), c);
      return +(-(r2 + (n2 - i2) / (s2 ? i2 - u2 : u2 - i2)) || 0);
    }, a: function(t3) {
      return t3 < 0 ? Math.ceil(t3) || 0 : Math.floor(t3);
    }, p: function(t3) {
      return { M: c, y: h, w: o, d: a, D: d, h: u, m: s, s: i, ms: r, Q: f }[t3] || String(t3 || "").toLowerCase().replace(/s$/, "");
    }, u: function(t3) {
      return void 0 === t3;
    } }, g = "en", D = {};
    D[g] = M;
    var p = "$isDayjsObject", S = function(t3) {
      return t3 instanceof _ || !(!t3 || !t3[p]);
    }, w = function t3(e2, n2, r2) {
      var i2;
      if (!e2)
        return g;
      if ("string" == typeof e2) {
        var s2 = e2.toLowerCase();
        D[s2] && (i2 = s2), n2 && (D[s2] = n2, i2 = s2);
        var u2 = e2.split("-");
        if (!i2 && u2.length > 1)
          return t3(u2[0]);
      } else {
        var a2 = e2.name;
        D[a2] = e2, i2 = a2;
      }
      return !r2 && i2 && (g = i2), i2 || !r2 && g;
    }, O = function(t3, e2) {
      if (S(t3))
        return t3.clone();
      var n2 = "object" == typeof e2 ? e2 : {};
      return n2.date = t3, n2.args = arguments, new _(n2);
    }, b = v;
    b.l = w, b.i = S, b.w = function(t3, e2) {
      return O(t3, { locale: e2.$L, utc: e2.$u, x: e2.$x, $offset: e2.$offset });
    };
    var _ = function() {
      function M2(t3) {
        this.$L = w(t3.locale, null, true), this.parse(t3), this.$x = this.$x || t3.x || {}, this[p] = true;
      }
      var m2 = M2.prototype;
      return m2.parse = function(t3) {
        this.$d = function(t4) {
          var e2 = t4.date, n2 = t4.utc;
          if (null === e2)
            return /* @__PURE__ */ new Date(NaN);
          if (b.u(e2))
            return /* @__PURE__ */ new Date();
          if (e2 instanceof Date)
            return new Date(e2);
          if ("string" == typeof e2 && !/Z$/i.test(e2)) {
            var r2 = e2.match($);
            if (r2) {
              var i2 = r2[2] - 1 || 0, s2 = (r2[7] || "0").substring(0, 3);
              return n2 ? new Date(Date.UTC(r2[1], i2, r2[3] || 1, r2[4] || 0, r2[5] || 0, r2[6] || 0, s2)) : new Date(r2[1], i2, r2[3] || 1, r2[4] || 0, r2[5] || 0, r2[6] || 0, s2);
            }
          }
          return new Date(e2);
        }(t3), this.init();
      }, m2.init = function() {
        var t3 = this.$d;
        this.$y = t3.getFullYear(), this.$M = t3.getMonth(), this.$D = t3.getDate(), this.$W = t3.getDay(), this.$H = t3.getHours(), this.$m = t3.getMinutes(), this.$s = t3.getSeconds(), this.$ms = t3.getMilliseconds();
      }, m2.$utils = function() {
        return b;
      }, m2.isValid = function() {
        return !(this.$d.toString() === l);
      }, m2.isSame = function(t3, e2) {
        var n2 = O(t3);
        return this.startOf(e2) <= n2 && n2 <= this.endOf(e2);
      }, m2.isAfter = function(t3, e2) {
        return O(t3) < this.startOf(e2);
      }, m2.isBefore = function(t3, e2) {
        return this.endOf(e2) < O(t3);
      }, m2.$g = function(t3, e2, n2) {
        return b.u(t3) ? this[e2] : this.set(n2, t3);
      }, m2.unix = function() {
        return Math.floor(this.valueOf() / 1e3);
      }, m2.valueOf = function() {
        return this.$d.getTime();
      }, m2.startOf = function(t3, e2) {
        var n2 = this, r2 = !!b.u(e2) || e2, f2 = b.p(t3), l2 = function(t4, e3) {
          var i2 = b.w(n2.$u ? Date.UTC(n2.$y, e3, t4) : new Date(n2.$y, e3, t4), n2);
          return r2 ? i2 : i2.endOf(a);
        }, $2 = function(t4, e3) {
          return b.w(n2.toDate()[t4].apply(n2.toDate("s"), (r2 ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(e3)), n2);
        }, y2 = this.$W, M3 = this.$M, m3 = this.$D, v2 = "set" + (this.$u ? "UTC" : "");
        switch (f2) {
          case h:
            return r2 ? l2(1, 0) : l2(31, 11);
          case c:
            return r2 ? l2(1, M3) : l2(0, M3 + 1);
          case o:
            var g2 = this.$locale().weekStart || 0, D2 = (y2 < g2 ? y2 + 7 : y2) - g2;
            return l2(r2 ? m3 - D2 : m3 + (6 - D2), M3);
          case a:
          case d:
            return $2(v2 + "Hours", 0);
          case u:
            return $2(v2 + "Minutes", 1);
          case s:
            return $2(v2 + "Seconds", 2);
          case i:
            return $2(v2 + "Milliseconds", 3);
          default:
            return this.clone();
        }
      }, m2.endOf = function(t3) {
        return this.startOf(t3, false);
      }, m2.$set = function(t3, e2) {
        var n2, o2 = b.p(t3), f2 = "set" + (this.$u ? "UTC" : ""), l2 = (n2 = {}, n2[a] = f2 + "Date", n2[d] = f2 + "Date", n2[c] = f2 + "Month", n2[h] = f2 + "FullYear", n2[u] = f2 + "Hours", n2[s] = f2 + "Minutes", n2[i] = f2 + "Seconds", n2[r] = f2 + "Milliseconds", n2)[o2], $2 = o2 === a ? this.$D + (e2 - this.$W) : e2;
        if (o2 === c || o2 === h) {
          var y2 = this.clone().set(d, 1);
          y2.$d[l2]($2), y2.init(), this.$d = y2.set(d, Math.min(this.$D, y2.daysInMonth())).$d;
        } else
          l2 && this.$d[l2]($2);
        return this.init(), this;
      }, m2.set = function(t3, e2) {
        return this.clone().$set(t3, e2);
      }, m2.get = function(t3) {
        return this[b.p(t3)]();
      }, m2.add = function(r2, f2) {
        var d2, l2 = this;
        r2 = Number(r2);
        var $2 = b.p(f2), y2 = function(t3) {
          var e2 = O(l2);
          return b.w(e2.date(e2.date() + Math.round(t3 * r2)), l2);
        };
        if ($2 === c)
          return this.set(c, this.$M + r2);
        if ($2 === h)
          return this.set(h, this.$y + r2);
        if ($2 === a)
          return y2(1);
        if ($2 === o)
          return y2(7);
        var M3 = (d2 = {}, d2[s] = e, d2[u] = n, d2[i] = t2, d2)[$2] || 1, m3 = this.$d.getTime() + r2 * M3;
        return b.w(m3, this);
      }, m2.subtract = function(t3, e2) {
        return this.add(-1 * t3, e2);
      }, m2.format = function(t3) {
        var e2 = this, n2 = this.$locale();
        if (!this.isValid())
          return n2.invalidDate || l;
        var r2 = t3 || "YYYY-MM-DDTHH:mm:ssZ", i2 = b.z(this), s2 = this.$H, u2 = this.$m, a2 = this.$M, o2 = n2.weekdays, c2 = n2.months, f2 = n2.meridiem, h2 = function(t4, n3, i3, s3) {
          return t4 && (t4[n3] || t4(e2, r2)) || i3[n3].slice(0, s3);
        }, d2 = function(t4) {
          return b.s(s2 % 12 || 12, t4, "0");
        }, $2 = f2 || function(t4, e3, n3) {
          var r3 = t4 < 12 ? "AM" : "PM";
          return n3 ? r3.toLowerCase() : r3;
        };
        return r2.replace(y, function(t4, r3) {
          return r3 || function(t5) {
            switch (t5) {
              case "YY":
                return String(e2.$y).slice(-2);
              case "YYYY":
                return b.s(e2.$y, 4, "0");
              case "M":
                return a2 + 1;
              case "MM":
                return b.s(a2 + 1, 2, "0");
              case "MMM":
                return h2(n2.monthsShort, a2, c2, 3);
              case "MMMM":
                return h2(c2, a2);
              case "D":
                return e2.$D;
              case "DD":
                return b.s(e2.$D, 2, "0");
              case "d":
                return String(e2.$W);
              case "dd":
                return h2(n2.weekdaysMin, e2.$W, o2, 2);
              case "ddd":
                return h2(n2.weekdaysShort, e2.$W, o2, 3);
              case "dddd":
                return o2[e2.$W];
              case "H":
                return String(s2);
              case "HH":
                return b.s(s2, 2, "0");
              case "h":
                return d2(1);
              case "hh":
                return d2(2);
              case "a":
                return $2(s2, u2, true);
              case "A":
                return $2(s2, u2, false);
              case "m":
                return String(u2);
              case "mm":
                return b.s(u2, 2, "0");
              case "s":
                return String(e2.$s);
              case "ss":
                return b.s(e2.$s, 2, "0");
              case "SSS":
                return b.s(e2.$ms, 3, "0");
              case "Z":
                return i2;
            }
            return null;
          }(t4) || i2.replace(":", "");
        });
      }, m2.utcOffset = function() {
        return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
      }, m2.diff = function(r2, d2, l2) {
        var $2, y2 = this, M3 = b.p(d2), m3 = O(r2), v2 = (m3.utcOffset() - this.utcOffset()) * e, g2 = this - m3, D2 = function() {
          return b.m(y2, m3);
        };
        switch (M3) {
          case h:
            $2 = D2() / 12;
            break;
          case c:
            $2 = D2();
            break;
          case f:
            $2 = D2() / 3;
            break;
          case o:
            $2 = (g2 - v2) / 6048e5;
            break;
          case a:
            $2 = (g2 - v2) / 864e5;
            break;
          case u:
            $2 = g2 / n;
            break;
          case s:
            $2 = g2 / e;
            break;
          case i:
            $2 = g2 / t2;
            break;
          default:
            $2 = g2;
        }
        return l2 ? $2 : b.a($2);
      }, m2.daysInMonth = function() {
        return this.endOf(c).$D;
      }, m2.$locale = function() {
        return D[this.$L];
      }, m2.locale = function(t3, e2) {
        if (!t3)
          return this.$L;
        var n2 = this.clone(), r2 = w(t3, e2, true);
        return r2 && (n2.$L = r2), n2;
      }, m2.clone = function() {
        return b.w(this.$d, this);
      }, m2.toDate = function() {
        return new Date(this.valueOf());
      }, m2.toJSON = function() {
        return this.isValid() ? this.toISOString() : null;
      }, m2.toISOString = function() {
        return this.$d.toISOString();
      }, m2.toString = function() {
        return this.$d.toUTCString();
      }, M2;
    }(), k = _.prototype;
    return O.prototype = k, [["$ms", r], ["$s", i], ["$m", s], ["$H", u], ["$W", a], ["$M", c], ["$y", h], ["$D", d]].forEach(function(t3) {
      k[t3[1]] = function(e2) {
        return this.$g(e2, t3[0], t3[1]);
      };
    }), O.extend = function(t3, e2) {
      return t3.$i || (t3(e2, _, O), t3.$i = true), O;
    }, O.locale = w, O.isDayjs = S, O.unix = function(t3) {
      return O(1e3 * t3);
    }, O.en = D[g], O.Ls = D, O.p = {}, O;
  });
})(dayjs_min);
var dayjs_minExports = dayjs_min.exports;
const dayjs = /* @__PURE__ */ getDefaultExportFromCjs(dayjs_minExports);
const storage = {
  set: (key, value) => {
    return chrome.storage.local.set({ [key]: value });
  },
  get: async (key) => {
    const store = await chrome.storage.local.get(key);
    return store[key] ? JSON.parse(store[key]) : {};
  },
  remove: (key) => {
    chrome.storage.local.remove(key);
  },
  clear: () => {
    chrome.storage.local.clear();
  }
};
const getActiveTab = async () => {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0];
};
const clearActiveTab = async () => {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tabs.length) {
    chrome.tabs.remove(Number(tabs[0].id));
  }
};
const createtab = async (url, options = {}) => {
  return chrome.tabs.create({ url, ...options });
};
const createWindow = async (url, options = {}) => {
  return chrome.windows.create({ url, ...options });
};
const sendMessageToExtension = async (message) => {
  return chrome.runtime.sendMessage(message).catch((err) => {
    console.error(err);
  });
};
const sendMessageToContentScript = async (message) => {
  const activeTab = await getActiveTab();
  if (activeTab) {
    return chrome.tabs.sendMessage(Number(activeTab.id), message).catch(() => {
    });
  }
};
const getChromeUrl = (path) => {
  return chrome.runtime.getURL(path);
};
const injectCustomScript = (injectscript) => {
  const script = document.createElement("script");
  script.src = getChromeUrl(injectscript);
  script.type = "module";
  if (!script)
    return new Error("发生了错误");
  script.onload = function() {
    if (script.parentNode) {
      script.parentNode.removeChild(script);
    } else {
      document.removeChild(script);
    }
  };
  document.head.appendChild(script);
};
const sendMessageToContentScriptById = (tabId, message) => {
  return chrome.tabs.sendMessage(Number(tabId), message).catch((err) => {
    console.error(err);
  });
};
const sendMessageToContentScriptAllTabs = (message) => {
  return new Promise((resolve) => {
    try {
      chrome.tabs.query({ currentWindow: true }, async (tabs) => {
        if (tabs && tabs.length > 0) {
          try {
            const response = [];
            for (let i = 0; i < tabs.length; i++) {
              const rst = await chrome.tabs.sendMessage(Number(tabs[i].id), message).catch((err) => {
                response.push({
                  status: "fail",
                  tabId: tabs[i].id,
                  response: err
                });
              });
              response.push({
                status: "success",
                tabId: tabs[i].id,
                response: rst
              });
            }
            resolve(response);
          } catch (error) {
            console.log(error);
          }
        } else {
          console.log("当前没有活跃的tabs");
        }
      });
    } catch (error) {
      console.log(error);
    }
  });
};
const chromeAddListenerMessage = (callback) => {
  try {
    chrome.runtime.onMessage.addListener((request2, sender, sendResponse) => {
      sendResponse();
      callback(request2);
      return false;
    });
  } catch (error) {
    console.log(error);
  }
};
const t = (key) => {
  return chrome.i18n.getMessage(key);
};
const { get, set: set$1 } = storage;
const _StorageKit = class {
  constructor(key, defaultValue) {
    __publicField(this, "version", ref(0));
    __publicField(this, "update_key", ref("NOT_INIT"));
    __publicField(this, "storeRaw", ref({}));
    __publicField(this, "_key");
    __publicField(this, "defaultValue");
    this.defaultValue = defaultValue;
    this._key = `StorageKit_${key}`;
    this.init();
  }
  get inited() {
    return this.update_key.value !== "NOT_INIT";
  }
  static getInstance(key, defaultValue) {
    if (!this.instances || !this.instances.has(key)) {
      this.instances.set(key, new _StorageKit(key, defaultValue));
    }
    return this.instances.get(key);
  }
  static clearStorage(key) {
    storage.remove(`StorageKit_${key}`);
  }
  syncStore(changes, namespace) {
    if (namespace === "local" && changes[this._key]) {
      this.sync();
    }
  }
  async save(value) {
    this.update_key.value = this._key + Date.now().toString();
    const raw = {
      store: value ?? toRaw(this.storeRaw.value),
      version: toRaw(this.version.value),
      update_key: toRaw(this.update_key.value)
    };
    await set$1(this._key, JSON.stringify(raw));
    await this.sync();
  }
  async sync() {
    get(this._key).then((res) => {
      if (res && JSON.stringify(res) !== "{}") {
        if (res.update_key !== this.update_key.value) {
          if (this.update_key.value === res.update_key)
            return;
          this.storeRaw.value = res.store ?? this.defaultValue;
          this.version.value = res.version ?? 1;
          this.update_key.value = res.update_key ?? this._key + Date.now().toString();
        }
      } else {
        this.storeRaw.value = this.defaultValue;
        this.version.value = 1;
        this.update_key.value = this._key + Date.now().toString();
        this.save();
      }
    });
  }
  init() {
    chrome.storage.onChanged.addListener(this.syncStore.bind(this));
    this.sync();
  }
  purge() {
    chrome.storage.onChanged.removeListener(this.syncStore.bind(this));
  }
  get store() {
    if (this.inited) {
      return this.storeRaw.value ?? this.defaultValue;
    }
    return this.defaultValue;
  }
  setStore(data) {
    this.storeRaw.value = data;
    this.save();
  }
  clear() {
    this.storeRaw.value = this.defaultValue;
    this.save();
  }
  /**
   * 获取内存使用
   * @param key
   * @returns
   */
  static getStorageSize(key) {
    return chrome.storage.local.getBytesInUse(`StorageKit_${key}`);
  }
};
let StorageKit = _StorageKit;
__publicField(StorageKit, "instances", /* @__PURE__ */ new Map());
const set = "/assets/set.svg";
const notice = "/assets/notice.png";
const WebNotice = {
  name: "WebNotice",
  title: "Env Notice",
  inner: false,
  logo: chrome.runtime.getURL(notice),
  contentApp: true,
  settingApp: true,
  hooks: {
    async onContentInit() {
      sendMessageToContentScript({
        from: "background",
        code: "WebNotice",
        data: []
      });
    },
    async onPageshow() {
      sendMessageToContentScript({
        from: "background",
        code: "WebNotice",
        data: []
      });
    },
    async onDocVisibilitychange() {
      sendMessageToContentScript({
        from: "background",
        code: "WebNotice",
        data: []
      });
    }
  }
};
const layout = "/assets/layout.svg";
const AppLayout = {
  name: "AppLayout",
  title: "布局",
  logo: chrome.runtime.getURL(layout),
  inner: true,
  isLogin: false,
  contentApp: true,
  description: "布局",
  hooks: {}
};
const account = "/assets/account.svg";
const DevAccount = {
  name: "DevAccount",
  title: "Dev Account",
  logo: chrome.runtime.getURL(account),
  inner: false,
  width: "600px",
  popupApp: true,
  settingApp: true,
  hooks: {}
};
const link = "/assets/link.svg";
const LinkGo = {
  name: "LinkGo",
  title: "超链直达",
  logo: getChromeUrl(link),
  inner: false,
  settingApp: true,
  hooks: {
    onContentInit: async () => {
      sendMessageToContentScriptAllTabs({
        from: "background",
        code: "LinkGo"
      });
    }
  }
};
const cookie = "/assets/cookie.svg";
const StoragePortal = {
  name: "StoragePortal",
  title: "缓存传送门",
  inner: false,
  isLogin: false,
  logo: getChromeUrl(cookie),
  contentApp: true,
  settingApp: false,
  width: "600px",
  hooks: {
    onGetData: async (data) => {
      var _a;
      if (data.key === "cookies") {
        const { targetUrl, sourceUrl } = data.opt;
        if (!targetUrl && !sourceUrl)
          return;
        const cookies = await chrome.cookies.getAll({ domain: targetUrl });
        const tabs = await chrome.tabs.query({ url: `*://${targetUrl}/*` });
        if (tabs && ((_a = tabs[0]) == null ? void 0 : _a.id)) {
          sendMessageToContentScriptById(tabs[0].id, {
            from: "background",
            code: "StoragePortal",
            data: { key: "send-storage", from: sourceUrl }
          });
        }
        sendMessageToContentScript({
          from: "background",
          code: "StoragePortal",
          data: {
            key: "get-cookies",
            data: { cookies }
          }
        });
      }
      if (data.key === "tabs") {
        const tabs = await chrome.tabs.query({ status: "complete" });
        const opens = tabs.map((t2) => {
          return { title: t2.title, url: t2.url };
        });
        sendMessageToContentScript({
          from: "background",
          code: "StoragePortal",
          data: {
            key: "get-tabs",
            data: { openWebSites: opens || [] }
          }
        });
      }
    },
    onSendData: async (data) => {
      sendMessageToContentScript({
        from: "background",
        code: "StoragePortal",
        data: { key: "get-storage", data }
      });
    },
    onCustomAction: async ({ data, key }) => {
      if (key === "clear-cookies") {
        const { targetUrl, cookies } = data;
        if (!targetUrl)
          return;
        cookies.forEach(async (n) => {
          await chrome.cookies.remove({
            url: targetUrl,
            name: n
          });
        });
      }
    }
  }
};
const count = "/assets/count.svg";
const getDaysOpenWebs = (data) => {
  const dates = /* @__PURE__ */ new Set();
  data == null ? void 0 : data.forEach((item) => {
    if (item.date)
      dates.add(item.date);
  });
  return Array.from(dates).map((date) => {
    const webs = data.filter((item) => item.date === date);
    const webMap = /* @__PURE__ */ new Map();
    webs.forEach((item) => {
      if (webMap.has(item.url)) {
        const old = webMap.get(item.url);
        webMap.set(item.url, {
          ...old,
          totalTime: "",
          count: old.count + 1
        });
      } else {
        webMap.set(item.url, {
          url: item.url,
          title: item.title,
          totalTime: "",
          count: 1
        });
      }
    });
    return {
      date,
      webs: Array.from(webMap.values())
    };
  }).sort((a, b) => dayjs(b.date).valueOf() - dayjs(a.date).valueOf());
};
const STORE_KEY$3 = "BrowseBehavior";
const useBrowseBehaviorStore = () => {
  const storageKit = StorageKit.getInstance(STORE_KEY$3, {
    webStatics: []
  });
  const addRecord = async (opt) => {
    var _a, _b;
    while (!storageKit.inited) {
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    const { tabId, url, title, date, startTime } = opt;
    const tab = (_a = storageKit.store.webStatics) == null ? void 0 : _a.find(
      (item) => item.tabId === tabId
    );
    if (tab) {
      if (tab.url === url)
        return;
      tab.tabId = "";
      tab.endTime = dayjs().format("YYYY-MM-DD HH:mm:ss");
    }
    if (!storageKit.storeRaw.value.webStatics) {
      storageKit.storeRaw.value.webStatics = [];
    }
    (_b = storageKit.storeRaw.value.webStatics) == null ? void 0 : _b.push({
      tabId,
      url,
      title,
      date,
      startTime,
      endTime: ""
    });
    storageKit.save();
  };
  const updateEndTime = (tabId, date, endTime) => {
    var _a;
    (_a = storageKit.storeRaw.value.webStatics) == null ? void 0 : _a.forEach((item) => {
      if (item.tabId === tabId && item.date === date) {
        item.tabId = "";
        item.endTime = endTime;
      }
    });
    storageKit.save();
  };
  const webStaticsMate = computed(() => storageKit.store.webStatics);
  const daysWebStatics = computed(() => {
    return getDaysOpenWebs(webStaticsMate.value).map((item) => {
      return {
        date: item.date,
        webs: item.webs.sort((a, b) => b.count - a.count)
      };
    });
  });
  const queryByDate = (day) => {
    var _a;
    const date = dayjs(day).format("YYYY-MM-DD");
    return (_a = daysWebStatics.value) == null ? void 0 : _a.find((item) => item.date === date);
  };
  const clear = () => {
    storageKit.clear();
  };
  const inited = computed(() => {
    return storageKit.inited;
  });
  return {
    daysWebStatics,
    queryByDate,
    addRecord,
    updateEndTime,
    clear,
    inited
  };
};
const BrowseBehavior = {
  name: "BrowseBehavior",
  title: "浏览数据",
  logo: chrome.runtime.getURL(count),
  inner: false,
  settingApp: true,
  popupApp: true,
  hooks: {
    onTabUpdate: async (tabs) => {
      const { addRecord } = useBrowseBehaviorStore();
      const [tabId, changeinfo, tab] = tabs;
      const host = new URL(tab.url).host;
      if (tab.url.startsWith("chrome://"))
        return;
      if (tab.url.startsWith("chrome-extension://"))
        return;
      if (["extension", "newtab"].includes(host))
        return;
      if (changeinfo.url) {
        await addRecord({
          tabId,
          url: new URL(tab.url).host,
          title: tab.title,
          date: dayjs().format("YYYY-MM-DD"),
          startTime: dayjs().format("YYYY-MM-DD HH:mm:ss")
        });
      }
    },
    onTabRemove: async (tabs) => {
      const [tabId] = tabs;
      const { updateEndTime } = useBrowseBehaviorStore();
      const endTime = dayjs().format("YYYY-MM-DD HH:mm:ss");
      const taday = dayjs().format("YYYY-MM-DD");
      updateEndTime(tabId, taday, endTime);
    }
  }
};
const click = "/assets/click.svg";
const defaultStore$2 = () => {
  return {
    status: 0,
    clickCount: 0
  };
};
const STORE_KEY$2 = "ClickCount";
const useClickCountStore = () => {
  const storageKit = StorageKit.getInstance(
    STORE_KEY$2,
    defaultStore$2()
  );
  const status = computed(() => {
    return storageKit.store.status;
  });
  const count2 = computed(() => {
    return storageKit.store.clickCount;
  });
  const add = async (count22 = 1) => {
    storageKit.storeRaw.value.clickCount += count22;
    await storageKit.save();
  };
  const set2 = (val) => {
    if (val === 0) {
      storageKit.storeRaw.value.status = 0;
      storageKit.storeRaw.value.clickCount = 0;
    }
    storageKit.storeRaw.value.status = val;
    storageKit.save();
  };
  return {
    status,
    count: count2,
    add,
    set: set2
  };
};
const ClickCount = {
  name: "ClickCount",
  title: "点击计数器",
  logo: getChromeUrl(click),
  inner: false,
  popupApp: true,
  settingApp: false,
  hooks: {
    onContentInit: async () => {
      sendMessageToContentScript({
        from: "background",
        code: "ClickCount",
        data: {
          key: "init-click"
        }
      });
    },
    onPageshow: async () => {
      sendMessageToContentScript({
        from: "background",
        code: "ClickCount",
        data: {
          key: "init-click"
        }
      });
    },
    onDocVisibilitychange: async () => {
      sendMessageToContentScript({
        from: "background",
        code: "ClickCount",
        data: {
          key: "init-click"
        }
      });
    },
    onCustomAction: async ({ key }) => {
      const { set: set2 } = useClickCountStore();
      if (key === "reset-click")
        set2(0);
      if (key === "start-click")
        set2(1);
      if (key === "stop-click")
        set2(2);
      if (key === "end-click")
        set2(3);
    }
  }
};
const apps = [
  WebNotice,
  AppLayout,
  DevAccount,
  LinkGo,
  StoragePortal,
  BrowseBehavior,
  ClickCount
];
const linkApp = [
  {
    name: "AppSetting",
    title: "设置",
    logo: getChromeUrl(set),
    inner: true,
    isLogin: true,
    contentApp: true,
    linkUrl: "setting.html"
  }
];
const settingApps = [
  {
    title: "应用商店",
    name: "AppStore",
    logo: getChromeUrl(set),
    inner: true,
    isLogin: false,
    settingApp: true
  },
  {
    title: "插件缓存",
    name: "AppStorage",
    logo: getChromeUrl(set),
    inner: true,
    isLogin: false,
    settingApp: true
  },
  {
    title: "用户信息",
    name: "AppUser",
    logo: getChromeUrl(set),
    inner: true,
    isLogin: false,
    settingApp: true
  }
];
const appsRaw = [
  ...apps.map((a) => ({
    ...a,
    name: a.name,
    title: a.title,
    logo: a.logo,
    inner: a.inner,
    width: a.width
  })),
  ...linkApp,
  ...settingApps
];
const defaultActive = [];
const defaultStore$1 = {
  version: 2,
  apps: appsRaw,
  actives: defaultActive,
  installed: []
};
const innerStoreKeys = ["AppStore", "AppAuth", "AppTheme", "AppNotice"];
const STORE_KEY$1 = "AppStore";
const useApp = () => {
  const storageKit = StorageKit.getInstance(STORE_KEY$1, defaultStore$1);
  const inited = computed(() => {
    return storageKit.inited;
  });
  const isAppInstall = (name) => {
    var _a;
    const app = storageKit.store.apps.find((a) => a.name === name);
    if (!app)
      return false;
    if (app.inner)
      return true;
    return (_a = storageKit.store.installed) == null ? void 0 : _a.includes(name);
  };
  const isAppActive = (name) => {
    var _a;
    const app = storageKit.store.apps.find((a) => a.name === name);
    if (!app)
      return false;
    if (app.inner)
      return true;
    if (!isAppInstall(name))
      return false;
    return (_a = storageKit.store.actives) == null ? void 0 : _a.includes(name);
  };
  const innerApps = computed(() => {
    return storageKit.store.apps.filter((a) => a.inner);
  });
  const contentInnerApps = computed(() => {
    return innerApps.value.filter((a) => a.contentApp);
  });
  const contentApps = computed(() => {
    const apps22 = storageKit.store.apps.filter(
      (a) => !a.inner && a.contentApp && isAppActive(a.name)
    );
    return apps22 || [];
  });
  const popupApps = computed(() => {
    return storageKit.store.apps.filter((a) => a.popupApp && isAppActive(a.name)) || [];
  });
  const settingApps2 = computed(() => {
    var _a;
    return ((_a = storageKit == null ? void 0 : storageKit.store) == null ? void 0 : _a.apps.filter((a) => a.settingApp)) || [];
  });
  const installApps = computed(() => {
    return storageKit.store.apps.filter((a) => isAppInstall(a.name) || a.inner) || [];
  });
  const installWithSettingApps = computed(() => {
    return settingApps2.value.filter((a) => isAppInstall(a.name) && !a.inner) || [];
  });
  const allCustomApps = computed(() => {
    return storageKit.store.apps.filter((a) => !a.inner) || [];
  });
  const settingInnerApps = computed(() => {
    return settingApps2.value.filter((a) => a.inner);
  });
  const apps2 = computed(() => {
    var _a;
    return ((_a = storageKit == null ? void 0 : storageKit.store) == null ? void 0 : _a.apps) || [];
  });
  const updateAppState = (name, isActive) => {
    var _a;
    if (!isAppInstall(name))
      return false;
    if (!storageKit.storeRaw.value.actives)
      storageKit.storeRaw.value.actives = [];
    if (isActive) {
      if (!storageKit.storeRaw.value.actives.includes(name)) {
        (_a = storageKit.storeRaw.value) == null ? void 0 : _a.actives.push(name);
      }
    } else {
      storageKit.storeRaw.value.actives = storageKit.storeRaw.value.actives.filter((n) => n !== name);
    }
    storageKit.save();
  };
  const sortApps = (list) => {
    const apps22 = list.map((name) => {
      return storageKit.storeRaw.value.apps.find(
        (app) => app.name === name
      );
    });
    storageKit.storeRaw.value.apps = storageKit.storeRaw.value.apps.filter((app) => !list.includes(app.name)).concat(apps22);
    storageKit.save();
  };
  const installApp = (name, switchStatus) => {
    var _a, _b, _c, _d;
    if (!isAppInstall(name)) {
      (_a = storageKit.storeRaw.value.installed) == null ? void 0 : _a.push(name);
      (_b = storageKit.storeRaw.value.actives) == null ? void 0 : _b.push(name);
    } else if (switchStatus) {
      storageKit.storeRaw.value.installed = (_c = storageKit.storeRaw.value.installed) == null ? void 0 : _c.filter((n) => n !== name);
      storageKit.storeRaw.value.actives = (_d = storageKit.storeRaw.value.actives) == null ? void 0 : _d.filter((n) => n !== name);
    }
    storageKit.save();
  };
  const syncStore = async () => {
    await storageKit.sync();
  };
  const storeKeys = computed(() => {
    return [
      {
        name: "核心",
        value: innerStoreKeys
      },
      ...allCustomApps.value.map((a) => {
        return {
          name: a.title,
          value: a.name
        };
      })
    ];
  });
  const reset = () => {
    storageKit.clear();
  };
  const clearStorage = (name) => {
    StorageKit.clearStorage(name);
  };
  const getStorageSize = (key) => {
    return StorageKit.getStorageSize(key);
  };
  return {
    isAppActive,
    isAppInstall,
    installApp,
    apps: apps2,
    installApps,
    installWithSettingApps,
    sortApps,
    settingInnerApps,
    contentApps,
    contentInnerApps,
    popupApps,
    settingApps: settingApps2,
    updateAppState,
    allCustomApps,
    inited,
    syncStore,
    storeKeys,
    reset,
    clearStorage,
    getStorageSize
  };
};
const baseURL = "https://api.kinfuy.cn";
const requestInterceptors = (url, data) => {
  const headers = {
    "Content-Type": "application/json"
  };
  const { accessToken } = useAuth();
  if (accessToken.value) {
    headers.Authorization = `Bearer ${accessToken.value}`;
  }
  return {
    url: `${baseURL}${url}`,
    method: "POST",
    headers,
    body: JSON.stringify(data)
  };
};
const responseInterceptors = async (data) => {
  const { clearAuth } = useAuth();
  const rst = await data.json();
  if (rst.code === "000000") {
    return rst == null ? void 0 : rst.data;
  }
  if (rst.code === "100001") {
    throw new Error(rst.message);
  }
  if (rst.code === "100004") {
    clearAuth();
    throw new Error(rst.message);
  }
  throw new Error(rst.message);
};
const myFetch = async (url, data) => {
  const { url: _url, method, headers, body } = requestInterceptors(url, data);
  const rst = await fetch(_url, { method, headers, body });
  return await responseInterceptors(rst);
};
const request = {
  post: async (url, data) => {
    return await myFetch(url, data);
  },
  get: async (url, data) => {
    return await myFetch(url, data);
  }
};
const loginApi = async (data) => {
  return await request.post(`/login`, data);
};
const registerApi = async (data) => {
  return await request.post(`/register`, data);
};
const sendCodeApi = async (data) => {
  return await request.post(`/sendCode`, data);
};
const verifyEmailApi = async (data) => {
  return await request.post(`/verifyEmail`, data);
};
const activationVipApi = async (data) => {
  return await request.post(`/user/activationVip`, data);
};
const refreshTokenApi = async (data) => {
  return await request.post(`/refreshToken`, data);
};
const STORE_KEY = "AppAuth";
const defaultStore = () => {
  return { isLogin: false };
};
const useAuth = () => {
  const storageKit = StorageKit.getInstance(
    STORE_KEY,
    defaultStore()
  );
  const isLogin = computed(() => storageKit.store.isLogin);
  const user = computed(() => {
    return storageKit.store.user;
  });
  const subscription = computed(() => {
    const { user: user2 } = storageKit.store;
    if (user2 == null ? void 0 : user2.subscription) {
      switch (user2.subscription.type) {
        case 1:
          return {
            ...user2 == null ? void 0 : user2.subscription,
            name: "月卡会员"
          };
        case 2:
          return {
            ...user2 == null ? void 0 : user2.subscription,
            name: "季卡会员"
          };
        case 3:
          return {
            ...user2 == null ? void 0 : user2.subscription,
            name: "年卡会员"
          };
        case 4:
          return {
            ...user2 == null ? void 0 : user2.subscription,
            name: "周体验卡"
          };
        case 99:
          return {
            ...user2 == null ? void 0 : user2.subscription,
            name: "永久会员"
          };
      }
    }
    return null;
  });
  const accessToken = computed(() => {
    const { user: user2 } = storageKit.store;
    if (user2)
      return user2.accessToken;
    return null;
  });
  const refreshToken = computed(() => {
    const { user: user2 } = storageKit.store;
    if (user2)
      return user2.refreshToken;
    return null;
  });
  const setUser = (user2) => {
    storageKit.storeRaw.value = {
      user: user2,
      isLogin: true,
      lastLoginTime: /* @__PURE__ */ new Date()
    };
    storageKit.save();
  };
  const setSubscription = (subscription2) => {
    storageKit.storeRaw.value.user.subscription = subscription2;
    storageKit.save();
  };
  const clearAuth = () => {
    storageKit.clear();
  };
  const getRefreshToken = async () => {
    if (isLogin.value) {
      const res = await refreshTokenApi({
        refreshToken: storageKit.store.user.refreshToken,
        accessToken: storageKit.store.user.accessToken
      });
      if (res) {
        storageKit.storeRaw.value.user.accessToken = res.accessToken;
        storageKit.storeRaw.value.user.refreshToken = res.refreshToken;
        storageKit.save();
      } else {
        clearAuth();
      }
    }
  };
  return {
    isLogin,
    user,
    subscription,
    accessToken,
    refreshToken,
    setUser,
    clearAuth,
    setSubscription,
    getRefreshToken
  };
};
export {
  StorageKit as S,
  useAuth as a,
  createtab as b,
  createWindow as c,
  apps as d,
  chromeAddListenerMessage as e,
  commonjsGlobal as f,
  getChromeUrl as g,
  getDefaultExportFromCjs as h,
  sendCodeApi as i,
  clearActiveTab as j,
  sendMessageToExtension as k,
  loginApi as l,
  useClickCountStore as m,
  injectCustomScript as n,
  dayjs as o,
  activationVipApi as p,
  sendMessageToContentScript as q,
  registerApi as r,
  storage as s,
  t,
  useApp as u,
  verifyEmailApi as v,
  getActiveTab as w,
  useBrowseBehaviorStore as x,
  set as y
};
