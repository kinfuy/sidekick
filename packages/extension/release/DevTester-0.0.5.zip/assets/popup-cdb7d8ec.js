import "./modulepreload-polyfill-7faf532e.js";
import { u as useTheme, c as createApp } from "./useTheme-a51fa13a.js";
import { w as withInstall, C as ConfigProvider, p as popupInstall } from "./index-e515ae7b.js";
import { E as Empty, _ as _export_sfc } from "./store-c3deb960.js";
import { _ as _sfc_main$1 } from "./ToolItem.vue_vue_type_script_setup_true_lang-76bad7cc.js";
import { d as defineComponent, X as getChromeUrl, aR as set, a5 as sendMessageToExtension, R as useApp, r as ref, aq as onBeforeUnmount, a6 as watchEffect, ai as provide, o as openBlock, a0 as createBlock, am as withCtx, u as unref, a as createBaseVNode, c as createElementBlock, a7 as renderList, I as Fragment, ab as resolveDynamicComponent, a1 as createCommentVNode, n as normalizeClass } from "./useApp-9e3cc9f6.js";
import { M as Message } from "./message-d1775bf2.js";
import "./util-9e04540b.js";
const ElConfigProvider = withInstall(ConfigProvider);
const _hoisted_1 = { class: "popup-slider" };
const _hoisted_2 = {
  key: 0,
  class: "popup-content"
};
const _hoisted_3 = ["src"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "popup",
  setup(__props) {
    const setIcon = getChromeUrl(set);
    sendMessageToExtension({
      from: Message.Form.POPUP_MESSAGE,
      to: Message.Target.SERVERWORKER,
      code: "onPopupOpen",
      data: {}
    });
    const { theme } = useTheme();
    const { popupApps, inited } = useApp();
    const current = ref();
    const appClick = (app2) => {
      current.value = app2;
    };
    onBeforeUnmount(() => {
      sendMessageToExtension({
        from: Message.Form.POPUP_MESSAGE,
        to: Message.Target.SERVERWORKER,
        code: "onPopupClose",
        data: {}
      });
      current.value = void 0;
    });
    const handleSet = () => {
      var _a;
      const query = current.value ? `#${(_a = current.value) == null ? void 0 : _a.name}` : "";
      window.open(getChromeUrl(`setting.html${query}`), "_blank");
    };
    watchEffect(() => {
      if (popupApps.value.length === 0 && inited.value) {
        handleSet();
        window.close();
      }
      if (popupApps.value.length > 0) {
        current.value = popupApps.value[0];
      }
    });
    provide("appContent", {
      openSet: handleSet
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(ElConfigProvider), { size: "small" }, {
        default: withCtx(() => {
          var _a, _b, _c;
          return [
            createBaseVNode("div", {
              class: normalizeClass(["popup-app", [unref(theme)]])
            }, [
              createBaseVNode("div", _hoisted_1, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(unref(popupApps), (app2) => {
                  var _a2;
                  return openBlock(), createBlock(_sfc_main$1, {
                    key: app2.name,
                    title: app2.title,
                    logo: app2.logo,
                    active: app2.name === ((_a2 = current.value) == null ? void 0 : _a2.name),
                    onClick: ($event) => appClick(app2)
                  }, null, 8, ["title", "logo", "active", "onClick"]);
                }), 128))
              ]),
              unref(popupApps).length ? (openBlock(), createElementBlock("div", _hoisted_2, [
                createBaseVNode("img", {
                  class: "popup-set",
                  src: unref(setIcon),
                  onClick: handleSet
                }, null, 8, _hoisted_3),
                unref(isRegister)(`Popup${(_a = current.value) == null ? void 0 : _a.name}`) ? (openBlock(), createBlock(resolveDynamicComponent(`Popup${(_b = current.value) == null ? void 0 : _b.name}`), {
                  key: (_c = current.value) == null ? void 0 : _c.name
                })) : (openBlock(), createBlock(unref(Empty), {
                  key: 1,
                  text: "暂无配置项"
                }))
              ])) : createCommentVNode("", true)
            ], 2)
          ];
        }),
        _: 1
      });
    };
  }
});
const popup_vue_vue_type_style_index_0_scoped_ac517cd5_lang = "";
const popup = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-ac517cd5"]]);
const index = "";
const app = createApp(popup);
if (app)
  popupInstall(app);
const isRegister = (name) => {
  if (!app)
    return false;
  return app.component(name);
};
app.mount("#popup-app");
