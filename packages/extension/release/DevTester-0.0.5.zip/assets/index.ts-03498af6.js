import { M as Message } from "./message-d1775bf2.js";
import { i as injectPostMessage } from "./util-9e04540b.js";
function wrapHistoryMethod(type, history2) {
  const originalMethod = history2[type];
  const event = new CustomEvent(type, {
    detail: {
      // TypeScript 中 Event 不直接支持 arguments 属性，因此我们使用 detail 来传递参数
      arguments: []
    },
    bubbles: true,
    cancelable: true
  });
  return function(...args) {
    const result = originalMethod.apply(history2, args);
    event.detail.arguments = args;
    window.dispatchEvent(event);
    return result;
  };
}
function enhanceHistory() {
  if (history.__sidekick__) {
    return;
  }
  if ("pushState" in history) {
    history.pushState = wrapHistoryMethod("pushState", history);
  }
  if ("replaceState" in history) {
    history.replaceState = wrapHistoryMethod("replaceState", history);
  }
  history.__sidekick__ = true;
}
enhanceHistory();
window.addEventListener("pushState", () => {
  injectPostMessage({
    from: Message.Form.INJECT_MESSAGE,
    to: Message.Target.SERVERWORKER,
    code: "onUrlChange",
    data: { url: window.location.href }
  });
});
window.addEventListener("replaceState", () => {
  injectPostMessage({
    from: Message.Form.INJECT_MESSAGE,
    to: Message.Target.SERVERWORKER,
    code: "onUrlChange",
    data: { url: window.location.href }
  });
});
window.addEventListener("popstate", () => {
  injectPostMessage({
    from: Message.Form.INJECT_MESSAGE,
    to: Message.Target.SERVERWORKER,
    code: "onUrlChange",
    data: { url: window.location.href }
  });
});
document.addEventListener("DOMContentLoaded", () => {
  injectPostMessage({
    from: Message.Form.CONTENT_MESSAGE,
    to: Message.Target.SERVERWORKER,
    code: "onDocDOMContentLoaded",
    data: {
      url: window.location.href
    }
  });
});
window.addEventListener("hashchange", () => {
  injectPostMessage({
    from: Message.Form.INJECT_MESSAGE,
    to: Message.Target.SERVERWORKER,
    code: "onUrlChange",
    data: { url: window.location.href }
  });
});
document.addEventListener("visibilitychange", () => {
  let visible = false;
  if (document.visibilityState === "visible") {
    visible = true;
  }
  injectPostMessage({
    from: Message.Form.INJECT_MESSAGE,
    to: Message.Target.CONTENT,
    code: "onDocVisibilitychange",
    data: { visible, url: window.location.href }
  });
});
